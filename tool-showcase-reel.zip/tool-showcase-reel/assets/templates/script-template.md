# VO script template (11 beats)

Marks: «/» short pause · «…» longer pause · **bold** = stress. One paragraph = one take. Keep the refrain identical everywhere.

**0 · cold open (monitor)** — use the take of the refrain from paragraph 1 (no extra recording needed)

**1.** یه {{INPUT_1}} داری؟ / {{REFRAIN}}… / حالا {{OUTPUT_1}}.

**2.** یا می‌خوای خیلی سریع {{INPUT_2}} رو {{OUTPUT_2}} کنی؟ / اونم {{REFRAIN}}.

**3.** {{SITUATION_3}}؟ / اونم {{REFRAIN}}… / و {{OUTPUT_3}} تحویلش بگیر.

**4.** و همین‌جوری بیشتر از **{{COUNT_SPOKEN}}** تا {{UNIT_WORD}} رو عوض کن؛ / رایگان، / {{WHERE_IT_RUNS}}، / بدون هیچ {{LIMIT_WORD}}!

**5.** یکی از **{{PAIN_ADJECTIVE}}** کارای دنیا، / {{OLD_WAY}}. / هرکدومم یه جور {{BARS_WORD}} دارن؛ / یکی {{LIMIT_1}}، / یکی {{LIMIT_2}}، / یکی {{LIMIT_3}}… / و آخرش {{WASTE_LINE}} / و از این صفحه / به اون صفحه می‌ریم.

**6.** **ولی** این ابزار… / اسمش **{{TOOL_NAME_FA}}**‌ئه. / رایگان و متن‌باز.

**7.** {{CAT_1}}، / {{CAT_2}}، / {{CAT_3}} و {{CAT_4}} و {{CAT_5}}، / بدون اینکه حتی {{BADGE_THING}} داشته باشی، / {{CAT_6}} و {{CAT_7}}، / {{CAT_8}}… / حتی {{CAT_9}} و {{CAT_10}}.

**8.** چون همه‌چی {{WHERE_IT_RUNS}} انجام می‌شه؛ / نه {{ANSWER_1}}، / نه {{ANSWER_2}}، / نه {{ANSWER_3}}.

**9.** کامنت کن «**{{CTA_KEYWORD}}**» / تا لینکش رو برات بفرستم.

**10 · tail** — the refrain take again (no extra recording)

Checks before recording: every number verified on the official site today · ANSWER_1..3 answer LIMIT_1..3 in the same order · the tool name is not said before paragraph 6 · Latin words have a pronunciation note.
