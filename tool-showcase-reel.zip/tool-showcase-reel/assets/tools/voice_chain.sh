#!/usr/bin/env bash
# Voice processing chains. Run AFTER edit_vo.py. Output: mono 48 kHz, −16 LUFS stem, tempo ×1.1.
# usage: voice_chain.sh raw  <edited.wav> <out.wav>     (clean mic recording, noise floor ≈ −60 dB or lower)
#        voice_chain.sh enhanced <edited.wav> <out.wav> (vendor "enhanced" file — adds a tiny room so it sounds less synthetic)
set -euo pipefail
MODE=$1; IN=$2; OUT=$3
TEMPO=${TEMPO:-1.1}
if [ "$MODE" = raw ]; then
  ffmpeg -v error -y -i "$IN" -af "highpass=f=80,afftdn=nr=8:nf=-62:tn=1,equalizer=f=210:t=q:w=1.1:g=-2.5,equalizer=f=3500:t=q:w=1.4:g=2.5,highshelf=f=10000:g=2,deesser=i=0.35,acompressor=threshold=-22dB:ratio=3:attack=6:release=120:makeup=3,atempo=$TEMPO,loudnorm=I=-16:TP=-2:LRA=8" -ar 48000 -ac 1 "$OUT"
else
  TMP=$(mktemp --suffix=.wav)
  python3 - "$IN" "$TMP" <<'PY'
import sys, numpy as np, soundfile as sf
from scipy.signal import fftconvolve
y, sr = sf.read(sys.argv[1]); rng = np.random.default_rng(7)
n = int(0.25 * sr); ir = np.zeros(n); ir[0] = 1
for d, g in [(0.007, .35), (0.011, .28), (0.017, .22), (0.023, .16), (0.031, .12)]: ir[int(d * sr)] += g   # early reflections
ir += rng.standard_normal(n) * np.exp(-np.arange(n) / (0.06 * sr)) * 0.05                               # short tail
wet = fftconvolve(y, ir)[:len(y)]; wet /= np.max(np.abs(wet)) / np.max(np.abs(y))
z = 0.9 * y + 0.1 * wet                                                                                  # 10 % wet
b = rng.standard_normal(len(z)); b = np.convolve(b, np.ones(40) / 40, "same"); z += b / np.std(b) * 10 ** (-64 / 20)  # room tone −64 dB
sf.write(sys.argv[2], z.astype(np.float32), sr)
PY
  ffmpeg -v error -y -i "$TMP" -af "highpass=f=75,afftdn=nf=-32:nr=5,equalizer=f=220:t=q:w=1:g=-2,equalizer=f=3200:t=q:w=1.2:g=1,highshelf=f=9000:g=-2.5,deesser=i=0.3,acompressor=threshold=-20dB:ratio=2.5:attack=8:release=140:makeup=2,atempo=$TEMPO,loudnorm=I=-16:TP=-2:LRA=8" -ar 48000 -ac 1 "$OUT"
  rm -f "$TMP"
fi
ffmpeg -hide_banner -i "$OUT" -af ebur128 -f null - 2>&1 | grep -E "^\s+I:" | tail -1
