"""Sound design + mix. Places SFX at the event times (audio/ev.json from scripts/dump_events.js), adds four
synthesized hits the packs usually lack (metal bars clang, fuse crackle, low boom, CRT power-off), ducks the
SFX 4.5 dB under speech and writes the pre-master mix.

usage: python3 sfx_mix.py voice_stem.wav sfx_map.json ev.json out_premix.wav [out_sfx_stem.wav]
Levels: every sample is normalised so its loudest 100 ms = −12 dB RMS, then the per-cue gain below is applied.
"""
import sys, json, subprocess, numpy as np, soundfile as sf
from scipy.signal import butter, sosfilt

VOICE, MAP, EVJ, OUT = sys.argv[1:5]
STEM = sys.argv[5] if len(sys.argv) > 5 else None
SR = 48000
E = json.load(open(EVJ)); M = json.load(open(MAP)); BASE = M["pack_dir"]; ROLES = M["roles"]
db = lambda d: 10 ** (d / 20)
N = int(E["DUR"] * SR)
bus = np.zeros((N, 2)); cache = {}

def load(role):
    if role in cache: return cache[role]
    if role not in ROLES: print("skip (no file mapped):", role); cache[role] = None; return None
    raw = subprocess.run(["ffmpeg", "-v", "error", "-i", BASE + ROLES[role], "-f", "f32le", "-ac", "2", "-ar", str(SR), "-"],
                         capture_output=True, check=True).stdout          # ffmpeg decodes what libsndfile can't
    x = np.frombuffer(raw, dtype=np.float32).reshape(-1, 2).astype(np.float64)
    w = int(0.1 * SR); r = np.sqrt(np.convolve((x ** 2).mean(1), np.ones(w) / w, "same"))
    x = x / (r.max() + 1e-9) * db(-12)
    cache[role] = (x, int(np.argmax(r)), int(np.argmax(r > r.max() * db(-30))))
    return cache[role]

def put(role, t, g=0.0, align="start", maxlen=None, fade=0.05, pan=0.0):
    """align='peak' puts the loudest moment of the sample on t (whooshes, risers); 'start' puts its onset on t."""
    s = load(role)
    if s is None: return
    x, pk, on = s
    if maxlen:
        x = x[: on + int(maxlen * SR)].copy(); k = min(len(x), int(fade * SR)); x[-k:] *= np.linspace(1, 0, k)[:, None]
    i = int(t * SR) - (pk if align == "peak" else on)
    if i < 0: x = x[-i:]; i = 0
    j = min(N, i + len(x))
    if j > i: bus[i:j] += x[: j - i] * db(g) * np.array([1 - max(0, pan), 1 + min(0, pan)])

rng = np.random.default_rng(3)
def env(n, a, r):
    tt = np.arange(n) / SR; return np.minimum(1, tt / max(a, 1e-4)) * np.exp(-np.maximum(0, tt - a) / r)
def synth(x, t, g):
    i = int(t * SR); j = min(N, i + len(x)); bus[i:j] += np.repeat(x[: j - i, None], 2, 1) * db(g)
def clang():
    n = int(0.9 * SR); tt = np.arange(n) / SR
    return sum(np.sin(2 * np.pi * f * tt) * a for f, a in [(187, 1), (523, .6), (1033, .4), (1712, .3), (2591, .2)]) * env(n, 0.001, 0.2) / 3
def boom():
    n = int(1.6 * SR); tt = np.arange(n) / SR
    return np.sin(2 * np.pi * (46 + 34 * np.exp(-tt * 8)) * tt) * env(n, 0.004, 0.5) * 0.8
def crackle(d):
    n = int(d * SR); x = np.zeros(n)
    for _ in range(int(d * 60)):
        i = int(rng.uniform(0, 1) * (n - 600)); m = int(rng.uniform(80, 500))
        x[i:i + m] += rng.standard_normal(m) * env(m, 0.0003, 0.002) * rng.uniform(0.3, 1)
    return sosfilt(butter(2, [900, 9000], btype="band", fs=SR, output="sos"), x) * 0.5 + \
        sosfilt(butter(2, 3000, btype="high", fs=SR, output="sos"), rng.standard_normal(n)) * 0.03
def crt_off():
    n = int(0.45 * SR); tt = np.arange(n) / SR
    return np.sin(2 * np.pi * np.cumsum(np.geomspace(3500, 70, n)) / SR) * env(n, 0.002, 0.15) * 0.35

# ---------------- cue sheet (event -> sound, gain dB) ----------------
for t in E["monIntro"] + E["mon"]: put("monitor_cut", t, -6)
put("punch_through", E["S1"] - 0.02, -4, "peak")
for k in (1, 2, 3):
    if k == 1: put("card_in", E["e1In"] + 0.1, -9)
    put("grab", E[f"e{k}Ctrl"] + 0.3, -8)
    put("ring_open", E[f"e{k}Ctrl"] + 0.58, -10)
    put("hover", max(E[f"e{k}Ctrl"] + 1.0, E[f"e{k}Drop"] - 0.45) + 0.22, -12)
    put("drop", E[f"e{k}Drop"], -4)
    put("converted", E[f"e{k}Drop"] + 0.22, -8)
put("key", E["e1Ctrl"] + 0.2, -9)
for t in (E["S2"], E["S3"]): put("whip", t, -5, "peak")
put("stamp", E["e2Drop"] + 0.22, -12)
put("grow", E["e3Drop"] + 0.14, -13, maxlen=0.9)
put("zoom_out", E["zoomOut"] + 0.35, -9, "peak")
put("burst", E["burst"], -9)
put("odometer", E["odoSpin"], -8, maxlen=E["odoLand"] - E["odoSpin"] + 0.5, fade=0.25)
put("odometer_lock", E["odoLand"] + 0.28, -9)
put("lock_pop", E["odoLand"] + 0.32, -10)
for k in ("chip1", "chip2", "chip3"): put("chip", E[k], -9)
put("pain_in", E["painIn"] + 0.1, -6, "peak")
for i, t in enumerate(E["tabs"]): put("tab_pop", t + 0.05, -12, pan=[-.3, .3, -.2, .2, 0][i])
put("ticking", E["tabs"][2], -18, maxlen=E["S6"] - E["tabs"][2] - 0.2, fade=0.4)
put("bars_whoosh", E["bars"], -10, "peak")
synth(clang(), E["bars"] + 0.18, -9)
for k in ("box1", "box2", "box3"): put("error", E[k], -8)
for i, t in enumerate(E["shuffle"]): put("shuffle", t + 0.12, -13, "peak", pan=(-.35 if i % 2 == 0 else .35))
synth(crackle(E["fuseHit"] - E["fuse"] + 0.05), E["fuse"], -8)
put("riser", E["fuseHit"], -6, "peak")
synth(boom(), E["fuseHit"], -8)
put("impact_shine", E["fuseHit"] + 0.02, -12)
put("logo_pop", E["logoPop"], -7, "peak")
put("detect", E["detLogo"], -11)
for i in range(3): put("chip", E["freeChips"] + i * 0.18, -11)
put("window_open", E["S7"] + 0.05, -11, maxlen=1.4, fade=0.4)
for t in E["cats"]: put("category", t, -9)
put("backspace", E["office"] + 0.05, -9)
put("converted", E["office"] + 0.3, -10)
put("scene_whoosh", E["S8"] + 0.1, -9, "peak")
put("data", E["laptop"] + 0.6, -12)
put("monitor_cut", E["cloudNo"], -9)
for t in E["strike"]: put("confirm", t, -10)
put("zoom_out", E["S9"] + 0.15, -11, "peak")
for k in range(4): put("type", E["typing"] - 0.25 + k * 0.09, -8)
put("send", E["send"], -8)
put("message", E["dm"], -9)
synth(crt_off(), E["crtOff"], -8)

# ---------------- duck SFX under speech, sum ----------------
vo, sr = sf.read(VOICE); assert sr == SR, "voice stem must be 48 kHz"
if vo.ndim > 1: vo = vo.mean(1)
vo = vo[:N] if len(vo) >= N else np.pad(vo, (0, N - len(vo)))
w = int(0.03 * SR)
ve = np.sqrt(np.convolve(vo ** 2, np.ones(w) / w, "same"))
act = np.clip((20 * np.log10(ve + 1e-9) + 40) / 15, 0, 1)        # 0 = silence (≤ −40 dB), 1 = speech (≥ −25 dB)
a = np.exp(-1 / (0.12 * SR)) ** 64; sm = np.empty_like(act); acc = 0.0
for i in range(0, N, 64):                                          # instant attack, 120 ms release
    v = act[i]; acc = v if v > acc else a * acc + (1 - a) * v; sm[i:i + 64] = acc
duck = db(-4.5 * sm)
mix = np.repeat(vo[:, None], 2, 1) + bus * duck[:, None]
sf.write(OUT, mix.astype(np.float32), SR)
if STEM: sf.write(STEM, (bus * duck[:, None]).astype(np.float32), SR)
print("premix written:", OUT)
