"""Pass 1 transcription: find every take in the raw voice file.
Splits the file at silences, groups pieces that are < 0.9 s apart, and transcribes each group with a local
Whisper (sherpa-onnx, int8). Output: one line per group "start-end  text" so you can see retakes and choose.

usage: python3 asr_chunks.py voice_16k_mono.wav <model_dir> [language=fa]
model_dir must contain <name>-encoder.int8.onnx, <name>-decoder.int8.onnx, <name>-tokens.txt (see references/step-by-step.md)
"""
import sys, glob, subprocess, wave, numpy as np, sherpa_onnx

wav, mdir = sys.argv[1], sys.argv[2]
lang = sys.argv[3] if len(sys.argv) > 3 else "fa"
enc = glob.glob(f"{mdir}/*-encoder.int8.onnx")[0]
dec = glob.glob(f"{mdir}/*-decoder.int8.onnx")[0]
tok = glob.glob(f"{mdir}/*-tokens.txt")[0]
rec = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=enc, decoder=dec, tokens=tok, language=lang, task="transcribe", num_threads=2)

w = wave.open(wav); sr = w.getframerate()
a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", wav, "-af", "silencedetect=noise=-38dB:d=0.35", "-f", "null", "-"],
                     capture_output=True, text=True).stderr
S = [float(l.split("silence_start:")[1].split()[0]) for l in log.splitlines() if "silence_start" in l]
E = [float(l.split("silence_end:")[1].split()[0]) for l in log.splitlines() if "silence_end" in l]
dur = len(a) / sr
pieces = [(s, e) for s, e in zip([0.0] + E, S + [dur]) if e - s > 0.15]
groups = []
for s, e in pieces:
    if groups and s - groups[-1][1] < 0.9 and e - groups[-1][0] < 28: groups[-1][1] = e   # whisper window is 30 s
    else: groups.append([s, e])
for s, e in groups:
    # 0.3 s silence before and 1.0 s after: without trailing silence Whisper drops the last word
    seg = np.concatenate([np.zeros(int(0.3 * sr), np.float32), a[int(max(0, s - 0.15) * sr):int(min(dur, e + 0.25) * sr)], np.zeros(int(1.0 * sr), np.float32)])
    st = rec.create_stream(); st.accept_waveform(sr, seg); rec.decode_stream(st)
    print(f"{s:7.2f}-{e:7.2f}  {st.result.text.strip()}", flush=True)
