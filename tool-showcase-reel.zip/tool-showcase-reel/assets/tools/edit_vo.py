"""Assemble the voice-over from the chosen takes (takes.json) with envelope-refined cut points.
- cut points come from the ANALYSIS file and are applied identically to every source given
  (e.g. the raw mic file and a vendor-enhanced copy of the same recording — they must be sample-aligned)
- each phrase boundary is pushed outward until the 5 ms envelope falls below LOW dBFS (no clipped word tails)
- pauses inside a section are shortened to at most MAXP seconds; section gaps come from takes.json
- every gap is filled with the recording's own room tone (no digital silence between cuts)

usage: python3 edit_vo.py takes.json analysis.wav phrases_raw.json src1.wav out1.wav [src2.wav out2.wav ...]
"""
import sys, json, subprocess, numpy as np, soundfile as sf

takes_path, ana_path, out_json = sys.argv[1:4]
pairs = [(sys.argv[i], sys.argv[i + 1]) for i in range(4, len(sys.argv), 2)]
T = json.load(open(takes_path))
LOW, MAXP = T.get("low_db", -52), T.get("max_pause", 0.24)
TONE = T["room_tone"]  # [start, end] seconds of pure room silence in the raw file

def load(p):
    x, sr = sf.read(p)
    return (x.mean(1) if x.ndim > 1 else x), sr
ana, sr = load(ana_path)
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", ana_path, "-af", "silencedetect=noise=-38dB:d=0.12", "-f", "null", "-"],
                     capture_output=True, text=True).stderr
S = [float(l.split("silence_start:")[1].split()[0]) for l in log.splitlines() if "silence_start" in l]
E = [float(l.split("silence_end:")[1].split()[0]) for l in log.splitlines() if "silence_end" in l]
sil = list(zip(S, E))
hop = int(0.005 * sr)
envdb = 20 * np.log10(np.sqrt(np.convolve(ana ** 2, np.ones(hop * 2) / (hop * 2), "same")[::hop] + 1e-12))

def refine_end(t, limit):
    i = int(t * sr / hop); j = int(min(limit, t + 0.35) * sr / hop)
    while i < j and envdb[i] > LOW: i += 1
    return min(limit, i * hop / sr + 0.03)
def refine_start(t, limit):
    i = int(t * sr / hop); j = int(max(limit, t - 0.15) * sr / hop)
    while i > j and envdb[i] > LOW: i -= 1
    return max(limit, i * hop / sr - 0.02)

plan, phrases, t = [], [], 0.0
for sec in T["sections"]:
    a, b, gap = sec["start"], sec["end"], sec["gap_before"]
    plan.append(("gap", gap)); t += gap
    inner = [(s, e) for s, e in sil if a < s and e < b]
    parts, cur = [], a
    for s, e in inner: parts.append([cur, s]); cur = e
    parts.append([cur, b])
    for k, p in enumerate(parts):
        lo = parts[k - 1][1] if k else a - 0.4
        hi = parts[k + 1][0] if k + 1 < len(parts) else b + 0.45
        p[0] = refine_start(p[0], lo); p[1] = refine_end(p[1], hi)
    for k, (s, e) in enumerate(parts):
        if k:
            pause = s - parts[k - 1][1]
            if pause > 0: q = min(pause, MAXP); plan.append(("gap", q)); t += q
        plan.append(("seg", s, e))
        phrases.append({"sec": sec["id"], "i": len(phrases), "t0": round(t + 0.02, 3), "t1": round(t + (e - s) - 0.03, 3), "raw": [round(s, 2), round(e, 2)]})
        t += e - s
plan.append(("gap", 0.7)); t += 0.7

FADE = int(0.008 * sr)
for src, out in pairs:
    x, sr2 = load(src); assert sr2 == sr, "all sources must share the sample rate"
    tone = x[int(TONE[0] * sr):int(TONE[1] * sr)].copy() * 0.9
    state = {"off": 0}
    def fill(n):
        o = np.resize(np.roll(tone, -state["off"]), n); state["off"] = (state["off"] + 7919) % len(tone)
        k = min(FADE, n // 2)
        if k: o[:k] *= np.linspace(0, 1, k); o[-k:] *= np.linspace(1, 0, k)
        return o
    buf = []
    for it in plan:
        if it[0] == "gap": buf.append(fill(int(round(it[1] * sr))))
        else:
            seg = x[int(it[1] * sr):int(it[2] * sr)].copy()
            seg[:FADE] *= np.linspace(0, 1, FADE); seg[-FADE:] *= np.linspace(1, 0, FADE)
            buf.append(seg)
    sf.write(out, np.concatenate(buf).astype(np.float32), sr)
json.dump(phrases, open(out_json, "w"), indent=1)
for p in phrases: print(p["i"], p["sec"], p["t0"], p["t1"], p["raw"])
print("TOTAL (before tempo)", round(t, 2))
