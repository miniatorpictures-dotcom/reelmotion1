"""Pass 2 transcription: phrase-level text inside the takes you chose (takes.json "sections").
Splits each chosen region at pauses >= 0.12 s (−36 dB) and transcribes each phrase, so you can write
script.json with exactly one entry per phrase.

usage: python3 asr_phrases.py voice_16k_mono.wav <model_dir> takes.json [language=fa]
"""
import sys, glob, json, subprocess, wave, numpy as np, sherpa_onnx

wav, mdir, takes = sys.argv[1:4]
lang = sys.argv[4] if len(sys.argv) > 4 else "fa"
cfg = json.load(open(takes))
enc = glob.glob(f"{mdir}/*-encoder.int8.onnx")[0]; dec = glob.glob(f"{mdir}/*-decoder.int8.onnx")[0]; tok = glob.glob(f"{mdir}/*-tokens.txt")[0]
rec = sherpa_onnx.OfflineRecognizer.from_whisper(encoder=enc, decoder=dec, tokens=tok, language=lang, task="transcribe", num_threads=2)
w = wave.open(wav); sr = w.getframerate()
a = np.frombuffer(w.readframes(w.getnframes()), dtype=np.int16).astype(np.float32) / 32768
log = subprocess.run(["ffmpeg", "-hide_banner", "-i", wav, "-af", "silencedetect=noise=-36dB:d=0.12", "-f", "null", "-"], capture_output=True, text=True).stderr
S = [float(l.split("silence_start:")[1].split()[0]) for l in log.splitlines() if "silence_start" in l]
E = [float(l.split("silence_end:")[1].split()[0]) for l in log.splitlines() if "silence_end" in l]
sil = list(zip(S, E))
for sec in cfg["sections"]:
    r0, r1 = sec["start"], sec["end"]
    cuts = [r0] + [x for p in sil for x in p if r0 < p[0] < r1 and r0 < p[1] < r1] + [r1]
    print(f"--- {sec['id']}")
    for i in range(0, len(cuts) - 1, 2):
        s, e = cuts[i], cuts[i + 1]
        seg = np.concatenate([np.zeros(int(.3 * sr), np.float32), a[int((s - 0.05) * sr):int((e + 0.08) * sr)], np.zeros(int(1 * sr), np.float32)])
        st = rec.create_stream(); st.accept_waveform(sr, seg); rec.decode_stream(st)
        print(f"{s:6.2f}-{e:6.2f}  {st.result.text.strip()}", flush=True)
