#!/usr/bin/env bash
# Master the pre-mix for Instagram: gentle glue compression, limiter, −14 LUFS integrated, −1 dBTP.
# usage: master.sh premix.wav mix.wav
set -euo pipefail
ffmpeg -v error -y -i "$1" -af "acompressor=threshold=-18dB:ratio=2:attack=15:release=200:makeup=1,alimiter=limit=0.89:attack=3:release=60,loudnorm=I=-14:TP=-1:LRA=10" -ar 48000 -ac 2 "$2"
ffmpeg -hide_banner -i "$2" -af ebur128=peak=true -f null - 2>&1 | grep -E "^\s+(I|Peak):" | tail -2
# Check: voice stem ≈ −16 LUFS, SFX stem ≈ −24 LUFS (8 LU under the voice), master −14 LUFS, peak ≤ −0.8 dBFS.
