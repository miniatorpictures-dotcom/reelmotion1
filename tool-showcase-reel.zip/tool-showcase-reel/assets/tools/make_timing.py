"""Phrase timings (audio/phrases_raw.json, timeline BEFORE tempo change) + script.json
-> timing.js with phrase and word-level caption timings on the final (tempo-adjusted) timeline.

usage: python3 make_timing.py audio/phrases_raw.json script.json timing.js
Word timing = phrase duration split in proportion to (letters + 1.5) per word. Good enough for word-by-word
highlighting; for exact word times use a forced aligner instead."""
import json, re, sys

ph_path, script_path, out_path = sys.argv[1:4]
ph = json.load(open(ph_path))
S = json.load(open(script_path))
TEMPO = S.get("tempo", 1.0)
TEXT, LINES, KEY = S["phrases"], S["lines"], S.get("keywords", {})
if len(TEXT) != len(ph):
    sys.exit(f"script has {len(TEXT)} phrases but the edited voice has {len(ph)} — split/merge script phrases to match the pauses")

words = []
for i, (p, t) in enumerate(zip(ph, TEXT)):
    t0, t1 = p["t0"] / TEMPO, p["t1"] / TEMPO
    ws = t.split(" ")
    wts = [len(re.sub(r"[^\w]", "", w)) + 1.5 for w in ws]
    tot = sum(wts); acc = t0
    for w, k in zip(ws, wts):
        d = (t1 - t0) * k / tot
        words.append({"w": w, "p": i, "s": round(acc, 3), "e": round(acc + d, 3), "c": KEY.get(w, "")})
        acc += d
phr = [{"t0": round(p["t0"] / TEMPO, 3), "t1": round(p["t1"] / TEMPO, 3), "text": t} for p, t in zip(ph, TEXT)]
lines = [{"s": phr[L[0]]["t0"], "e": phr[L[-1]]["t1"], "words": [i for i, w in enumerate(words) if w["p"] in L]} for L in LINES]
open(out_path, "w").write("window.PHR=" + json.dumps(phr, ensure_ascii=False) + ";\nwindow.WORDS=" +
                          json.dumps(words, ensure_ascii=False) + ";\nwindow.LINES=" + json.dumps(lines) + ";\n")
for i, p in enumerate(phr): print(i, p["t0"], p["t1"], p["text"])
