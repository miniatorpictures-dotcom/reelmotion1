// Key moments on the film timeline, derived from the voice timing (timing.js) + CFG.roles/anchors.
// Shared by the composition (browser) and the SFX builder (node: `node scripts/dump_events.js`).
(function (W) {
  const P = W.PHR, WD = W.WORDS, R = W.CFG.roles, A = W.CFG.anchors;
  const wt = (p, txt, end) => {
    if (txt === null || txt === undefined) return end ? P[p].t1 : P[p].t0;
    const w = WD.find((x) => x.p === p && x.w.includes(txt));
    if (!w) throw new Error(`anchor word not found: "${txt}" in phrase ${p} (${P[p] && P[p].text})`);
    return end ? w.e : w.s;
  };
  const at = (a) => wt(a[0], a[1]);
  const r3 = (x) => Math.round(x * 1000) / 1000;
  const TAIL = P.length - 1;
  // scene starts sit a little before the first phrase of each beat (values tuned on the original reel)
  const S1 = P[R.ex1.say].t0 - 0.32, S2 = P[R.ex2.say].t0 - 0.16, S3 = P[R.ex3.say].t0 - 0.19, S4 = P[R.payoff].t0 - 0.2;
  const S5 = P[R.pain.open].t0 - 0.25, S6 = P[R.reveal.name].t0 - 0.22, S7 = P[R.cats.first].t0 - 0.21;
  const S8 = P[R.local.open].t0 - 0.22, S9 = P[R.cta.say].t0 - 0.2, S10 = P[TAIL].t0 - 0.12;
  const crtOff = P[TAIL].t1 + 0.12;
  const tabsMid = at(A.tabsMid);
  const EV = {
    DUR: r3(crtOff + 0.55), TAIL,
    S1, S2, S3, S4, S5, S6, S7, S8, S9, S10,
    monIntro: WD.filter((w) => w.p === R.intro).map((w) => w.s),
    e1In: S1 + 0.02, e1Ctrl: P[R.ex1.refrain].t0 - 0.05, e1Drop: P[R.ex1.result].t0 + 0.02,
    e2In: S2 + 0.08, e2Ctrl: P[R.ex2.refrain].t0 - 0.05, e2Drop: at(A.e2Drop) + 0.05,
    e3In: S3 + 0.08, e3Ctrl: P[R.ex3.refrain].t0 - 0.05, e3Drop: at(A.e3Drop) - 0.05,
    zoomOut: S4, burst: P[R.payoff].t0 + 0.2, odoSpin: at(A.odoSpin) - 0.15, odoLand: at(A.odoLand),
    chip1: P[R.pros[0]].t0, chip2: P[R.pros[1]].t0, chip3: P[R.pros[2]].t0,
    painIn: S5, tabs: [P[R.pain.open].t0, P[R.pain.open].t0 + 0.55, tabsMid, tabsMid + 0.45, tabsMid + 0.9],
    bars: at(A.bars) - 0.05, barsOut: P[R.pain.l1].t0 - 0.12,
    box1: P[R.pain.l1].t0, box2: P[R.pain.l2].t0, box3: P[R.pain.l3].t0,
    shuffle: [0.3, 1.05, 1.8, 2.75, 3.3].map((d) => P[R.pain.shuffle].t0 + d),
    fuse: at(A.fuse), fuseHit: at(A.fuseHit) - 0.05, logoPop: at(A.logoPop) - 0.05,
    detLogo: at(A.logoPop) + 0.35, freeChips: P[R.reveal.chips].t0,
    video: S7 + 0.19,
    cats: A.cats.map(at),
    office: at(A.badge),
    laptop: P[R.local.open].t0, cloudNo: at(A.cloudNo),
    strike: A.strike.map(at),
    ctaIn: S9, typing: at(A.typing), send: P[R.cta.send].t0 + 0.25, dm: P[R.cta.send].t0 + 0.8,
    mon: WD.filter((w) => w.p === TAIL).map((w) => w.s),
    crtOff,
  };
  W.EV = EV; W.wt = wt;
})(typeof window !== "undefined" ? window : globalThis);
