/* Tool-showcase reel. One paused GSAP timeline; every tween is placed at absolute film time (seek-safe).
   All copy, colours and product data come from reel.config.js (window.CFG). */
window.__buildMain = function () {
  const E = window.EV, PHR = window.PHR, WORDS = window.WORDS, LINES = window.LINES, CFG = window.CFG, K = CFG.colors;
  const tl = gsap.timeline({ paused: true });
  const root = document.getElementById("root");
  const world = document.getElementById("world");
  const over = document.getElementById("over");

  // ---------- helpers ----------
  function mulberry32(a) { return function () { a |= 0; a = (a + 0x6d2b79f5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; }; }
  const rnd = mulberry32(20261021);
  function el(tag, cls, parent, css, html) {
    const e = document.createElement(tag);
    if (cls) e.className = cls;
    if (css) Object.assign(e.style, css);
    if (html !== undefined) e.innerHTML = html;
    (parent || world).appendChild(e);
    return e;
  }
  const px = (n) => n + "px";
  const SVGNS = "http://www.w3.org/2000/svg";
  function svg(tag, attrs, parent) { const e = document.createElementNS(SVGNS, tag); for (const k in attrs) e.setAttribute(k, attrs[k]); parent.appendChild(e); return e; }
  const isLat = (s) => /[A-Za-z0-9]/.test(s) && !/[؀-ۿ]/.test(s);
  // colour roles (names kept short): accent = signature, focus = warning, ex1..3 = hook examples, extra1..4 = variety
  const C = { mint: K.accent, red: K.focus, amber: K.ex1, blue: K.ex2, pink: K.ex3, purple: K.extra1, purple2: K.extra2, green: K.extra3, orange: K.extra4, ink: K.ink };
  const role = (r) => K[r] || r;
  const aRGB = K.accentRGB, fRGB = K.focusRGB;
  // tokens -> CSS variables
  const rs = document.documentElement.style;
  [["--bg", K.bg], ["--bg2", K.bg2], ["--ink", K.ink], ["--inkRGB", K.ink.replace("#", "").match(/../g).map((h) => parseInt(h, 16)).join(",")],
   ["--accent", K.accent], ["--accentRGB", aRGB], ["--focus", K.focus], ["--focusRGB", fRGB]].forEach(([k, v]) => rs.setProperty(k, v));
  document.getElementById("hudBrand").textContent = CFG.creatorHandle;

  function detBox(parent, x, y, w, h, color, tag) {
    const d = el("div", "det", parent, { left: px(x), top: px(y), width: px(w), height: px(h), color });
    el("div", "frame", d); for (let i = 0; i < 4; i++) el("i", "", d);
    const t = el("div", "tag", d, { background: color }, `<span>${tag}</span>`);
    tl.set(d, { opacity: 0 }, 0);
    return { d, t };
  }
  function showDet(b, at, dur) {
    tl.fromTo(b.d, { opacity: 0, scale: 1.14 }, { opacity: 1, scale: 1, duration: 0.32, ease: "expo.out", immediateRender: false }, at);
    tl.fromTo(b.t, { clipPath: "inset(0 100% 0 0)" }, { clipPath: "inset(0 0% 0 0)", duration: 0.35, ease: "steps(12)", immediateRender: false }, at + 0.08);
    if (dur) tl.to(b.d, { opacity: 0, duration: 0.15 }, at + dur);
  }

  // ---------- background driver (pure function of time) ----------
  const blobsEl = document.getElementById("blobs");
  const blobs = [0, 1, 2].map((i) => el("div", "blob", blobsEl, { background: `radial-gradient(circle, var(--c${i}) 0%, transparent 62%)` }));
  const pal = {};
  Object.entries(CFG.blobs).forEach(([scene, cols]) => { pal[scene === "S1" ? 0 : E[scene]] = cols; });
  Object.keys(pal).map(Number).sort((a, b) => a - b).forEach((t, k) => {
    const v = {}; pal[t].forEach((c, i) => (v["--c" + i] = c));
    if (k === 0) tl.set(root, v, 0); else tl.to(root, { ...v, duration: 0.6, ease: "sine.inOut" }, t - 0.1);
  });
  const grain = document.getElementById("grain");
  const hudTxt = document.getElementById("hudTxt");
  const grid = document.getElementById("grid");
  const objAt = (t) => (t < E.S4 ? 1 : t < E.S5 ? 48 : t < E.fuseHit ? 5 : t < E.S8 ? 1 : t < E.S9 ? 3 : 1);
  const drv = { t: 0 };
  tl.to(drv, {
    t: E.DUR, duration: E.DUR, ease: "none",
    onUpdate() {
      const t = drv.t, f = Math.round(t * 30);
      blobs.forEach((b, i) => {
        const x = [-250, 420, 80][i] + Math.sin(t * 0.35 + i * 2.1) * 140;
        const y = [-200, 650, 1300][i] + Math.cos(t * 0.28 + i * 1.3) * 160;
        b.style.transform = `translate(${x}px, ${y}px)`;
      });
      grid.style.transform = `translateY(${(t * 6) % 90}px)`;
      const g = (f % 6); grain.style.transform = `translate(${[0, -37, 21, -64, 48, -12][g]}px, ${[0, 29, -51, 13, -33, 57][g]}px)`;
      hudTxt.textContent = `${CFG.hudPrefix} · f ${String(f).padStart(4, "0")} · obj ${objAt(t)}`;
    },
  }, 0);
  tl.fromTo("#progFill", { scaleX: 0 }, { scaleX: 1, duration: E.DUR, ease: "none" }, 0);

  // ---------- captions ----------
  const cap = document.getElementById("cap");
  // keyword colour roles from script.json: accent | focus | ex1 | ex2 | ex3 | extra1..4 | tool
  const capCol = (c) => role(c === "tool" ? "tool1" : c);
  LINES.forEach((L, li) => {
    const d = el("div", "capline", cap);
    const spans = L.words.map((wi) => {
      const w = WORDS[wi];
      const core = w.w.replace(/[؟.,،؛!…]+$/g, ""), tail = w.w.slice(core.length);
      const s = el("span", "w", d, {}, isLat(core) ? `<span class="lat">${core}</span>${tail}` : w.w);
      return { s, w };
    });
    const next = LINES[li + 1];
    const tIn = L.s - 0.05, tOut = Math.min(next ? next.s - 0.16 : E.S10, L.e + 0.9);
    tl.fromTo(d, { opacity: 0, y: 18 }, { opacity: 1, y: 0, duration: 0.18, ease: "power3.out", immediateRender: false }, tIn);
    tl.set(d, { opacity: 0 }, 0);
    tl.to(d, { opacity: 0, y: -10, duration: 0.1, ease: "power2.in" }, tOut);
    spans.forEach(({ s, w }) => {
      tl.to(s, { opacity: 1, duration: 0.08 }, w.s);
      if (w.c) tl.fromTo(s, { color: C.ink, scale: 1.12 }, { color: capCol(w.c), scale: 1, duration: 0.25, ease: "back.out(2)", immediateRender: false }, w.s);
    });
  });
  tl.set(cap, { opacity: 0 }, 0); tl.set(cap, { opacity: 1 }, E.S1 - 0.01);
  tl.to(cap, { opacity: 0, duration: 0.01 }, E.mon[0] - 0.02);

  // ---------- examples (hook) ----------
  const strip = el("div", "", world, {}); strip.id = "strip";
  const EXT = [[E.e1In, E.e1Ctrl, E.e1Drop], [E.e2In, E.e2Ctrl, E.e2Drop], [E.e3In, E.e3Ctrl, E.e3Drop]];
  const EX = CFG.examples.map((x, i) => ({ ...x, col: role(x.color), tIn: EXT[i][0], tCtrl: EXT[i][1], tDrop: EXT[i][2], ctrl: i === 0 }));

  function thumbFor(i, parent) {
    const th = el("div", "thumb", parent);
    const ty = EX[i].thumb, g = EX[i].image || ["#ffb36b", "#ff6a6d", "#7a2f73", "#2b1640"];
    if (ty === "image") {
      th.style.background = `linear-gradient(180deg,${g[0]} 0%,${g[1]} 42%,${g[2]} 75%,${g[3]} 100%)`;
      el("div", "", th, { position: "absolute", left: "200px", top: "88px", width: "92px", height: "92px", borderRadius: "50%", background: "radial-gradient(circle,#fff6d8,#ffd27a 60%,rgba(255,210,122,0) 72%)" });
      th.insertAdjacentHTML("beforeend", '<svg width="368" height="300" style="position:absolute;left:0;top:0"><path d="M0 230 L70 170 L120 205 L190 130 L260 200 L310 165 L368 210 L368 300 L0 300Z" fill="#2a1235"/><path d="M0 260 L90 215 L170 250 L250 222 L368 262 L368 300 L0 300Z" fill="#160a1f"/></svg>');
    } else if (ty === "doc") {
      th.style.background = "#f1f2f6";
      el("div", "", th, { position: "absolute", left: "34px", top: "30px", width: "180px", height: "22px", borderRadius: "6px", background: C.blue });
      for (let k = 0; k < 7; k++) el("div", "", th, { position: "absolute", left: "34px", top: px(78 + k * 28), width: px([300, 280, 296, 220, 300, 260, 180][k]), height: "12px", borderRadius: "6px", background: "#c9ccd6" });
    } else {
      th.style.background = "linear-gradient(160deg,#28304a,#141824 70%)";
      el("div", "", th, { position: "absolute", left: "40px", top: "40px", width: "140px", height: "140px", borderRadius: "50%", background: `radial-gradient(circle,${C.pink}99,transparent 70%)` });
      el("div", "", th, { position: "absolute", left: "150px", top: "100px", width: "70px", height: "70px", borderRadius: "50%", background: "rgba(255,255,255,.9)" }, '<svg width="70" height="70"><path d="M28 22 L50 35 L28 48Z" fill="#141824"/></svg>');
      el("div", "", th, { position: "absolute", left: "26px", right: "26px", bottom: "26px", height: "8px", borderRadius: "4px", background: "rgba(255,255,255,.2)" });
      el("div", "", th, { position: "absolute", left: "26px", width: "120px", bottom: "26px", height: "8px", borderRadius: "4px", background: C.pink });
    }
    return th;
  }

  const ring = el("div", "", world); ring.id = "ring";
  const ringGlass = el("div", "", ring); ringGlass.id = "ringGlass";
  const ringSvg = svg("svg", { width: 600, height: 600, id: "ringSvg" }, ring);
  const sector = (a0, a1, r0, r1) => {
    const p = (a, r) => [300 + r * Math.cos((a * Math.PI) / 180), 300 + r * Math.sin((a * Math.PI) / 180)];
    const [x0, y0] = p(a0, r1), [x1, y1] = p(a1, r1), [x2, y2] = p(a1, r0), [x3, y3] = p(a0, r0);
    return `M${x0},${y0} A${r1},${r1} 0 0 1 ${x1},${y1} L${x2},${y2} A${r0},${r0} 0 0 0 ${x3},${y3}Z`;
  };
  const segs = [], hls = [];
  for (let k = 0; k < 8; k++) {
    const a0 = -90 + k * 45 + 1.6, a1 = -90 + (k + 1) * 45 - 1.6;
    segs.push(svg("path", { d: sector(a0, a1, 108, 294), fill: "rgba(20,20,28,.42)", stroke: "rgba(255,255,255,.16)", "stroke-width": 1.5 }, ringSvg));
    hls.push(svg("path", { d: sector(a0, a1, 108, 294), fill: C.purple, opacity: 0 }, ringSvg));
  }
  const ringCenter = el("div", "glass", ring, {}, ""); ringCenter.id = "ringCenter";
  const labelSets = EX.map((ex) => {
    const g = el("div", "", ring, { position: "absolute", inset: "0" });
    ex.labels.forEach(([a, b], k) => {
      const m = ((-90 + k * 45 + 22.5) * Math.PI) / 180;
      el("div", "seglab", g, { left: px(300 + 200 * Math.cos(m)), top: px(300 + 200 * Math.sin(m) - 26) }, `${a}<small>${b}</small>`);
    });
    const c = el("div", "", ringCenter, { position: "absolute", inset: "0", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center" }, `<b>${ex.center[0]}</b><span>${ex.center[1]}</span>`);
    tl.set([g, c], { opacity: 0 }, 0);
    return { g, c };
  });
  tl.set(ring, { opacity: 0, scale: 0.6, rotation: -25 }, 0);

  const cursor = el("div", "", world); cursor.id = "cursor";
  cursor.innerHTML = '<svg width="64" height="64" viewBox="0 0 64 64"><path d="M10 6 L10 50 L22 39 L30 58 L38 54 L30 36 L46 36 Z" fill="#fff" stroke="#0d0d0f" stroke-width="3" stroke-linejoin="round"/></svg>';
  tl.set(cursor, { x: 1000, y: 1700, opacity: 0, transformOrigin: "10px 6px" }, 0);
  const keyCtrl = el("div", "keychip glass", world, { left: "690px", top: "790px", borderRadius: "16px" }, `<span class="lat">${CFG.keyLabel}</span>`);
  tl.set(keyCtrl, { opacity: 0, scale: 0.6 }, 0);

  EX.forEach((ex, i) => {
    const box = el("div", "ex", strip, { left: px(i * 1080) });
    const card = el("div", "glass card", box);
    thumbFor(i, card);
    el("div", "fname lat", card, {}, `${ex.file[0]}<span style="opacity:.5">${ex.file[1]}</span>`);
    const chipIn = el("div", "ext", card, { background: ex.col }, ex.chipIn);
    const chipOut = el("div", "ext", card, { background: C.mint }, ex.chipOut);
    const check = el("div", "", card, { position: "absolute", right: "-22px", top: "-22px", width: "64px", height: "64px", borderRadius: "50%", background: C.mint, boxShadow: `0 0 30px rgba(${aRGB},.6)` },
      `<svg width="64" height="64"><path d="M18 33 L28 43 L47 22" fill="none" stroke="${K.bg}" stroke-width="6" stroke-linecap="round" stroke-linejoin="round"/></svg>`);
    const dIn = detBox(box, 296, 296, 488, 538, ex.col, ex.det);
    const dOut = detBox(box, 296, 296, 488, 538, C.mint, ex.detOut);
    tl.set([chipOut, check], { opacity: 0 }, 0);
    tl.set(card, { opacity: i === 0 ? 0 : 1 }, 0);

    // ghost (thumbnail following the cursor)
    const ghost = el("div", "", world, { width: "150px", height: "124px" }); ghost.id = "ghost" + i;
    Object.assign(ghost.style, { position: "absolute", left: "0", top: "0", borderRadius: "20px", overflow: "hidden", border: "2px solid rgba(255,255,255,.55)", boxShadow: "0 24px 50px rgba(0,0,0,.55)" });
    const gth = thumbFor(i, ghost); Object.assign(gth.style, { left: "0", top: "0", right: "auto", width: "368px", height: "300px", transform: "scale(.41)", transformOrigin: "0 0", borderRadius: "0" });
    tl.set(ghost, { opacity: 0, x: 465, y: 500 }, 0);

    // entrance
    if (i === 0) tl.fromTo(card, { opacity: 0, y: 90, scale: 0.9, rotationX: 14, transformPerspective: 900 },
      { opacity: 1, y: 0, scale: 1, rotationX: 0, duration: 0.6, ease: "expo.out", immediateRender: false }, ex.tIn);
    else tl.fromTo(card, { scale: 0.92 }, { scale: 1, duration: 0.5, ease: "back.out(2)", immediateRender: false }, ex.tIn - 0.05);
    showDet(dIn, ex.tIn + 0.28);

    // Ctrl + grab + drag
    const T = ex.tCtrl;
    if (ex.ctrl) {
      tl.to(keyCtrl, { opacity: 1, scale: 1, duration: 0.3, ease: "back.out(2.4)" }, T - 0.1);
      tl.to(keyCtrl, { scale: 0.9, y: 6, duration: 0.08, yoyo: true, repeat: 1 }, T + 0.25);
      tl.to(keyCtrl, { opacity: 0, scale: 0.8, duration: 0.2 }, ex.tDrop + 0.1);
    }
    tl.set(cursor, { x: 980, y: 1660 }, T - 0.12);
    tl.to(cursor, { opacity: 1, duration: 0.12 }, T - 0.12);
    tl.to(cursor, { x: 560, y: 580, duration: 0.4, ease: "power3.out" }, T - 0.1);
    tl.to(cursor, { scale: 0.82, duration: 0.08 }, T + 0.3);
    tl.to(card, { opacity: 0.5, scale: 0.97, duration: 0.2 }, T + 0.32);
    tl.set(ghost, { x: 470, y: 520, scale: 0.6, rotation: 0 }, T + 0.33);
    tl.to(ghost, { opacity: 1, scale: 1, rotation: -6, duration: 0.18, ease: "back.out(2)" }, T + 0.33);
    tl.to(cursor, { x: 548, y: 1092, duration: 0.5, ease: "power2.inOut" }, T + 0.38);
    tl.to(ghost, { x: 488, y: 1030, duration: 0.5, ease: "power2.inOut" }, T + 0.4);
    // ring opens
    tl.set(labelSets[i].g, { opacity: 1 }, T + 0.55); tl.set(labelSets[i].c, { opacity: 1 }, T + 0.55);
    tl.fromTo(ring, { opacity: 0, scale: 0.55, rotation: -25 }, { opacity: 1, scale: 1, rotation: 0, duration: 0.45, ease: "back.out(1.5)", immediateRender: false }, T + 0.58);
    tl.fromTo(segs, { opacity: 0 }, { opacity: 1, duration: 0.2, stagger: 0.025, immediateRender: false }, T + 0.58);
    tl.fromTo(labelSets[i].g.children, { opacity: 0, scale: 0.7 }, { opacity: 1, scale: 1, duration: 0.25, stagger: 0.03, ease: "back.out(2)", immediateRender: false }, T + 0.68);
    // move to target segment (index 0)
    const m = ((-90 + 22.5) * Math.PI) / 180, tx = 240 + 300 + 200 * Math.cos(m), ty = 800 + 300 + 200 * Math.sin(m);
    const hov = Math.max(T + 1.0, ex.tDrop - 0.45);
    tl.to(cursor, { x: tx - 4, y: ty - 6, scale: 0.82, duration: 0.32, ease: "power2.inOut" }, hov);
    tl.to(ghost, { x: tx - 60, y: ty - 62, duration: 0.34, ease: "power2.inOut" }, hov + 0.02);
    tl.to(hls[0], { opacity: 1, duration: 0.12 }, hov + 0.22);
    // drop
    const D = ex.tDrop;
    tl.to(cursor, { scale: 1, duration: 0.1 }, D);
    tl.to(hls[0], { attr: { fill: C.mint }, duration: 0.08 }, D);
    tl.to(ghost, { scale: 0.2, opacity: 0, duration: 0.2, ease: "power2.in" }, D + 0.02);
    tl.to(ring, { scale: 1.08, opacity: 0, duration: 0.24, ease: "power2.in" }, D + 0.06);
    tl.set(hls[0], { opacity: 0, attr: { fill: C.purple } }, D + 0.32);
    tl.set([labelSets[i].g, labelSets[i].c], { opacity: 0 }, D + 0.32);
    tl.to(cursor, { x: 900, y: 1300, opacity: 0, duration: 0.4, ease: "power2.in" }, D + 0.25);
    tl.to(card, { opacity: 1, scale: 1, duration: 0.25, ease: "back.out(2)" }, D + 0.05);
    tl.to(chipIn, { y: -46, rotation: -10, opacity: 0, duration: 0.24, ease: "power2.in" }, D + 0.08);
    if (ex.payoff === "stamp") {
      tl.fromTo(chipOut, { opacity: 0, rotationX: -95, transformPerspective: 500, transformOrigin: "50% 0%" }, { opacity: 1, rotationX: 0, duration: 0.45, ease: "back.out(1.8)", immediateRender: false }, D + 0.16);
    } else {
      tl.fromTo(chipOut, { opacity: 0, y: 40, scale: 0.6 }, { opacity: 1, y: 0, scale: 1, duration: 0.36, ease: "back.out(2.2)", immediateRender: false }, D + 0.16);
    }
    tl.fromTo(check, { opacity: 0, scale: 0 }, { opacity: 1, scale: 1, duration: 0.35, ease: "back.out(3)", immediateRender: false }, D + 0.24);
    tl.to(dIn.d, { opacity: 0, duration: 0.12 }, D + 0.1);
    showDet(dOut, D + 0.2);
    // per-type payoff
    const th = card.querySelector(".thumb");
    if (ex.payoff === "flash") {
      const fl = el("div", "", th, { position: "absolute", inset: "0", background: "#fff" });
      tl.set(fl, { opacity: 0 }, 0);
      tl.to(fl, { opacity: 0.85, duration: 0.05 }, D + 0.1); tl.to(fl, { opacity: 0, duration: 0.4 }, D + 0.15);
    } else if (ex.payoff === "stamp") {
      const ear = el("div", "", th, { position: "absolute", right: "0", top: "0", width: "86px", height: "86px", background: `linear-gradient(225deg, ${K.bg} 50%, #d7d9e2 50%)`, boxShadow: "-6px 6px 12px rgba(0,0,0,.25)", transformOrigin: "100% 0%" });
      const stamp = el("div", "lat", th, { position: "absolute", left: "34px", bottom: "26px", padding: "6px 16px", border: `4px solid ${C.red}`, color: C.red, borderRadius: "10px", fontWeight: "800", fontSize: "34px" }, ex.stamp || ex.chipOut);
      tl.set([ear, stamp], { scale: 0, opacity: 0 }, 0);
      tl.to(ear, { scale: 1, opacity: 1, duration: 0.3, ease: "power3.out" }, D + 0.12);
      tl.fromTo(stamp, { scale: 2.2, opacity: 0, rotation: -14 }, { scale: 1, opacity: 1, rotation: -8, duration: 0.3, ease: "power4.in", immediateRender: false }, D + 0.22);
    } else {
      const wv = el("div", "", th, { position: "absolute", inset: "0", background: `linear-gradient(160deg,${K.bg2},${K.bg})` });
      const bars = [];
      for (let k = 0; k < 26; k++) {
        const h = 30 + Math.abs(Math.sin(k * 0.7) * 120) * (0.5 + rnd() * 0.6);
        bars.push(el("div", "", wv, { position: "absolute", left: px(22 + k * 12.6), top: px(150 - h / 2), width: "7px", height: px(h), borderRadius: "4px", background: C.mint, boxShadow: `0 0 10px rgba(${aRGB},.5)` }));
      }
      tl.set(wv, { opacity: 0 }, 0); tl.set(bars, { scaleY: 0 }, 0);
      tl.to(wv, { opacity: 1, duration: 0.2 }, D + 0.1);
      tl.to(bars, { scaleY: 1, duration: 0.4, ease: "back.out(2)", stagger: { each: 0.018, from: "center" } }, D + 0.14);
      tl.to(bars, { scaleY: 0.55, duration: 0.3, ease: "sine.inOut", yoyo: true, repeat: 3, stagger: { each: 0.03, from: "random" } }, D + 0.6);
    }
  });
  // whips between examples (fast slide + light streaks)
  const streaks = [];
  for (let j = 0; j < 9; j++) {
    const sk = el("div", "", over, { position: "absolute", left: "0", top: px(260 + j * 150 + rnd() * 60), width: px(700 + rnd() * 600), height: px(2 + rnd() * 5), borderRadius: "4px",
      background: `linear-gradient(90deg, transparent, ${[C.amber, C.blue, C.pink, C.mint, "#ffffff"][j % 5]}, transparent)` });
    tl.set(sk, { opacity: 0 }, 0); streaks.push(sk);
  }
  [E.S2, E.S3].forEach((t, k) => {
    tl.to(strip, { x: -1080 * (k + 1), duration: 0.36, ease: "power4.inOut" }, t - 0.18);
    streaks.forEach((sk, j) => {
      tl.fromTo(sk, { x: 1300, opacity: 0 }, { x: -1500, opacity: 0.9, duration: 0.3, ease: "power2.inOut", immediateRender: false }, t - 0.16 + j * 0.012);
      tl.set(sk, { opacity: 0 }, t + 0.16 + j * 0.012);
    });
  });

  // ---------- S4 payoff: zoom out, format wall, odometer ----------
  tl.to(strip, { x: -1080, y: -560, scale: 0.3, duration: 0.7, ease: "expo.inOut" }, E.zoomOut);
  const wall = el("div", "", world, { position: "absolute", inset: "0" });
  const FMT = CFG.wall;
  const fcols = [C.amber, C.blue, C.pink, C.mint, C.purple, C.green, C.orange, C.red];
  const fchips = [];
  const slots = [];
  for (let r = 0; r < 3; r++) for (let c = 0; c < 6; c++) slots.push([110 + c * 172 + (r % 2) * 60, 470 + r * 62]);
  for (let r = 0; r < 4; r++) for (let c = 0; c < 6; c++) slots.push([110 + c * 172 + (r % 2) * 60, 1200 + r * 64]);
  for (let r = 0; r < 4; r++) slots.push([60, 700 + r * 110], [1020, 700 + r * 110]);
  FMT.forEach((f, k) => {
    if (k >= slots.length) return;
    const x = slots[k][0] + (rnd() - 0.5) * 40, y = slots[k][1] + (rnd() - 0.5) * 18;
    const c = fcols[k % fcols.length];
    const ch = el("div", "fchip", wall, { left: px(x - 50), top: px(y - 27), color: c, borderColor: c }, f);
    tl.set(ch, { opacity: 0, x: 540 - x, y: 830 - y, scale: 0.3 }, 0);
    tl.to(ch, { opacity: 0.32 + rnd() * 0.5, x: 0, y: 0, scale: 0.75 + rnd() * 0.35, rotation: (rnd() - 0.5) * 16, duration: 0.8 + rnd() * 0.3, ease: "expo.out" }, E.burst + k * 0.012);
    tl.to(ch, { x: (rnd() - 0.5) * 40, y: (rnd() - 0.5) * 30, duration: 5, ease: "sine.inOut" }, E.burst + 1.1);
    fchips.push(ch);
  });
  const odo = el("div", "glass", world, {}); odo.id = "odo";
  const digits = "۰۱۲۳۴۵۶۷۸۹";
  const target = CFG.odometer.digits;
  const cols = [0, 1, 2].map((k) => {
    const w = el("div", "wheel", odo, { left: px(40 + k * 180) });
    const col = el("div", "col", w);
    for (let n = 0; n < 30; n++) el("div", "d", col, {}, digits[n % 10]);
    return col;
  });
  el("div", "", odo, { position: "absolute", left: "590px", top: "92px", fontFamily: "FA", fontWeight: 900, fontSize: "120px", color: C.mint, textShadow: `0 0 30px rgba(${aRGB},.55)` }, "+");
  el("div", "", odo, { position: "absolute", left: "0", right: "0", top: "268px", textAlign: "center", fontWeight: 700, fontSize: "40px", direction: "rtl" }, CFG.odometer.label);
  tl.set(odo, { opacity: 0, scale: 0.85, y: 40 }, 0);
  tl.to(odo, { opacity: 1, scale: 1, y: 0, duration: 0.5, ease: "back.out(1.6)" }, E.burst - 0.1);
  cols.forEach((col, k) => {
    tl.set(col, { y: 0 }, 0);
    tl.to(col, { y: -(20 + target[k]) * 190, duration: 0.75 + k * 0.18, ease: "power3.out" }, E.odoSpin + k * 0.05);
  });
  const glint = el("div", "", odo, { position: "absolute", inset: "0", borderRadius: "34px", background: "linear-gradient(105deg, transparent 35%, rgba(255,255,255,.25) 50%, transparent 65%)" });
  tl.set(glint, { xPercent: -120 }, 0);
  tl.to(glint, { xPercent: 120, duration: 0.7, ease: "power2.inOut" }, E.odoLand + 0.15);
  const proRow = el("div", "", world, { position: "absolute", left: "0", right: "0", top: "1060px", height: "80px", display: "flex", justifyContent: "center", gap: "18px", direction: "rtl" });
  const pros = CFG.pros.map((t, k) => [t, [E.chip1, E.chip2, E.chip3][k]]).map(([t, at]) => {
    const c = el("div", "chip", proRow, { position: "relative", borderColor: `rgba(${aRGB},.5)` }, `<span style="color:${C.mint}">●</span> ${t}`);
    tl.set(c, { opacity: 0, y: 30, scale: 0.8 }, 0);
    tl.to(c, { opacity: 1, y: 0, scale: 1, duration: 0.35, ease: "back.out(2.2)" }, at);
    return c;
  });
  // S4 exit
  tl.to(odo, { opacity: 0, scale: 0.9, y: -40, duration: 0.3, ease: "power2.in" }, E.S5 - 0.05);
  tl.to(pros, { opacity: 0, y: 30, duration: 0.25, stagger: 0.03 }, E.S5 - 0.05);
  tl.to(fchips, { y: "+=420", opacity: 0, rotation: "+=25", duration: 0.55, ease: "power2.in", stagger: { each: 0.004, from: "random" } }, E.S5 - 0.1);
  tl.to(strip, { opacity: 0, duration: 0.3 }, E.S5 - 0.1);

  // ---------- S5 pain ----------
  const tabsWrap = el("div", "", world, { position: "absolute", inset: "0", zIndex: "0" });
  const DOM = CFG.tabs.domains;
  const TP = [[150, 470, -4], [130, 640, 3], [160, 560, -2], [140, 740, 4], [150, 620, -1]];
  const adSets = CFG.tabs.ads;
  const tabs = DOM.map((d, k) => {
    const t = el("div", "tab", tabsWrap, { left: px(TP[k][0]), top: px(TP[k][1]), zIndex: 10 + k });
    const bar = el("div", "bar", t, {}, "<i></i><i></i><i></i>");
    el("div", "url", bar, {}, "https://" + d);
    const body = el("div", "body", t);
    el("div", "", body, { position: "absolute", left: "30px", top: "120px", fontFamily: "Sora", fontWeight: 800, fontSize: "40px", color: "rgba(var(--inkRGB),.85)" }, CFG.tabs.title);
    el("div", "bigbtn", body, { top: "200px" }, CFG.tabs.button);
    el("div", "spin", body, { left: "360px", top: "320px" });
    adSets[k].forEach(([txt, col, x, y, w, h]) => {
      const a = el("div", "ad", body, { left: px(x), top: px(y), width: px(w), height: px(h), background: col, lineHeight: px(h), fontSize: px(Math.min(30, h * 0.4)) }, txt);
      tl.to(a, { opacity: 0.35, duration: 0.18, ease: "steps(1)", yoyo: true, repeat: 17 }, E.painIn + rnd() * 0.5);
    });
    tl.set(t, { opacity: 0, y: 140, scale: 0.88, rotation: TP[k][2] * 2 }, 0);
    tl.to(t, { opacity: 1, y: 0, scale: 1, rotation: TP[k][2], duration: 0.5, ease: "back.out(1.4)" }, E.tabs[k]);
    tl.to(t.querySelector(".spin"), { rotation: 360 * 14, duration: 13, ease: "none" }, E.painIn);
    return t;
  });
  // bars on the "limits" word
  const barsWord = el("div", "abs", world, {}, CFG.barsWord); barsWord.id = "barsWord";
  const barsV = [];
  for (let k = 0; k < 7; k++) barsV.push(el("div", "barv", world, { left: px(178 + k * 116) }));
  tl.set(barsWord, { opacity: 0 }, 0); tl.set(barsV, { y: -1300 }, 0);
  tl.to(tabs, { opacity: 0.22, duration: 0.2 }, E.bars - 0.15);
  tl.fromTo(barsWord, { opacity: 0, scale: 1.3 }, { opacity: 1, scale: 1, duration: 0.25, ease: "expo.out", immediateRender: false }, E.bars - 0.12);
  tl.to(barsV, { y: 0, duration: 0.42, ease: "bounce.out", stagger: 0.035 }, E.bars);
  tl.to(world, { x: 10, duration: 0.05, yoyo: true, repeat: 5, ease: "none" }, E.bars + 0.36);
  tl.to([barsWord, ...barsV], { opacity: 0, scale: 0.92, duration: 0.18 }, E.barsOut);
  tl.to(tabs, { opacity: 1, duration: 0.2 }, E.barsOut);
  const pb = [detBox(world, 150, 610, 560, 210, C.red, CFG.painBoxes[0]), detBox(world, 420, 900, 520, 210, C.red, CFG.painBoxes[1]), detBox(world, 170, 1150, 640, 200, C.red, CFG.painBoxes[2])];
  [E.box1, E.box2, E.box3].forEach((t, k) => { showDet(pb[k], t); tl.to(pb[k].d, { opacity: 0.25, duration: 0.05, yoyo: true, repeat: 3, ease: "steps(1)" }, t + 0.32); });
  tl.to(pb.map((b) => b.d), { opacity: 0, duration: 0.15 }, E.shuffle[0] - 0.15);
  const wasted = el("div", "abs mono", world, {}, ""); wasted.id = "wasted";
  const wv = { s: 0 };
  tl.set(wasted, { opacity: 0 }, 0);
  tl.to(wasted, { opacity: 1, duration: 0.2 }, E.tabs[2]);
  tl.fromTo(wv, { s: 0 }, { s: CFG.wastedSeconds, duration: E.S6 - E.tabs[2], ease: "power2.in", immediateRender: false,
    onUpdate() { const s = Math.floor(wv.s); wasted.textContent = `${CFG.wastedLabel}  ${String(Math.floor(s / 60)).padStart(2, "0")}:${String(s % 60).padStart(2, "0")}`; } }, E.tabs[2]);
  // shuffle: "from this page to that page"
  const order = [4, 3, 2, 1, 0]; let zmin = 9;
  E.shuffle.forEach((t, k) => {
    const idx = order[k % 5], tab = tabs[idx], dir = k % 2 ? 1 : -1;
    tl.to(tab, { x: 760 * dir, rotation: 14 * dir, opacity: 0, duration: 0.24, ease: "power3.in" }, t);
    tl.set(tab, { zIndex: zmin-- }, t + 0.25);
    tl.to(tab, { x: 0, rotation: TP[idx][2], opacity: 0.85, duration: 0.3, ease: "power3.out" }, t + 0.26);
  });

  // ---------- S6 reveal: fuse -> tool ----------
  const fuseSvg = svg("svg", { id: "fuse", width: 1080, height: 1920 }, world);
  const FP = "M860,1470 C1000,1300 160,1260 250,1060 C320,900 520,980 540,700";
  const rope = svg("path", { d: FP, fill: "none", stroke: "#b9a88a", "stroke-width": 9, "stroke-linecap": "round", "stroke-dasharray": "14 9", opacity: 0.9 }, fuseSvg);
  const ash = svg("path", { d: FP, fill: "none", stroke: "#1a1a1d", "stroke-width": 12, "stroke-linecap": "round" }, fuseSvg);
  const L = rope.getTotalLength();
  ash.setAttribute("stroke-dasharray", `${L} ${L}`);
  const spark = svg("g", {}, fuseSvg);
  svg("circle", { r: 70, fill: "rgba(255,170,60,.18)" }, spark);
  svg("circle", { r: 30, fill: "rgba(255,190,90,.55)" }, spark);
  svg("circle", { r: 11, fill: "#fff8e0" }, spark);
  for (let k = 0; k < 8; k++) svg("line", { x1: 0, y1: 0, x2: 0, y2: -(34 + (k % 3) * 14), stroke: "#ffd27a", "stroke-width": 4, "stroke-linecap": "round", transform: `rotate(${k * 45})` }, spark);
  tl.set(fuseSvg, { opacity: 0 }, 0);
  tl.set(ash, { attr: { "stroke-dashoffset": L } }, 0);
  const fp = { p: 0 };
  const placeSpark = () => { const pt = rope.getPointAtLength(fp.p * L); spark.setAttribute("transform", `translate(${pt.x},${pt.y}) rotate(${fp.p * 1400})`); ash.setAttribute("stroke-dashoffset", String(L - fp.p * L)); };
  tl.to(fuseSvg, { opacity: 1, duration: 0.15 }, E.fuse - 0.05);
  tl.fromTo(fp, { p: 0 }, { p: 1, duration: E.fuseHit - E.fuse, ease: "power1.in", onUpdate: placeSpark, immediateRender: false }, E.fuse);
  tl.call(placeSpark, null, 0);
  tl.to(fuseSvg, { opacity: 0, duration: 0.2 }, E.fuseHit + 0.05);
  const flash = el("div", "", over); flash.id = "flash";
  tl.to(flash, { opacity: 0.95, duration: 0.06 }, E.fuseHit);
  tl.to(flash, { opacity: 0, duration: 0.5, ease: "power2.out" }, E.fuseHit + 0.07);
  tabs.forEach((t, k) => {
    const ang = (k / 5) * Math.PI * 2;
    tl.to(t, { x: Math.cos(ang) * 900, y: Math.sin(ang) * 900, rotation: (k - 2) * 25, scale: 1.3, opacity: 0, duration: 0.55, ease: "power3.out" }, E.fuseHit);
  });
  tl.to(wasted, { opacity: 0, duration: 0.15 }, E.fuseHit);

  // logo placeholder: a segmented ring in the tool colours (replace with your own vector logo if you have rights to it)
  const logo = svg("svg", { id: "logo", width: 400, height: 400, viewBox: "0 0 400 400" }, world);
  const lsec = (a0, a1, r0, r1) => {
    const p = (a, r) => [200 + r * Math.cos((a * Math.PI) / 180), 200 + r * Math.sin((a * Math.PI) / 180)];
    const [x0, y0] = p(a0, r1), [x1, y1] = p(a1, r1), [x2, y2] = p(a1, r0), [x3, y3] = p(a0, r0);
    return `M${x0},${y0} A${r1},${r1} 0 0 1 ${x1},${y1} L${x2},${y2} A${r0},${r0} 0 0 0 ${x3},${y3}Z`;
  };
  const LCOL = CFG.tool.logoSegments.map(role), LA = CFG.tool.logoAccentIndex;
  const lsegs = LCOL.map((c, k) => {
    const a0 = -112 + k * (360 / 7) + 2.6, a1 = -112 + (k + 1) * (360 / 7) - 2.6;
    return svg("path", { d: lsec(a0, a1, 92, 190 + (k === LA ? 12 : 0)), fill: c }, logo);
  });
  const fileIcon = svg("path", { d: "M172 150 h40 l28 28 v72 h-68z", fill: K.toolIcon }, logo);
  svg("path", { d: "M212 150 v28 h28z", fill: K.tool1 }, logo);
  tl.set(logo, { opacity: 0 }, 0);
  tl.set(lsegs, { scale: 0, rotation: -60, svgOrigin: "200 200", opacity: 0 }, 0);
  tl.set(logo, { opacity: 1 }, E.fuseHit);
  tl.to(lsegs.filter((_, k) => k !== LA), { scale: 1, rotation: 0, opacity: 1, duration: 0.55, ease: "back.out(1.6)", stagger: 0.05 }, E.fuseHit + 0.02);
  tl.to(lsegs[LA], { scale: 1, rotation: 0, opacity: 1, duration: 0.5, ease: "back.out(3)" }, E.logoPop);
  tl.fromTo(lsegs[LA], { filter: `drop-shadow(0 0 0px ${K.tool3})` }, { filter: `drop-shadow(0 0 26px ${K.tool3})`, duration: 0.3, yoyo: true, repeat: 1, immediateRender: false }, E.logoPop + 0.3);
  tl.fromTo(fileIcon, { opacity: 0, y: 30 }, { opacity: 1, y: 0, duration: 0.35, ease: "back.out(2)", immediateRender: false }, E.fuseHit + 0.25);
  const wm = el("div", "abs", world, {}); wm.id = "wordmark";
  const wmL = CFG.tool.wordmark.split("").map((c) => el("span", "", wm, { display: "inline-block" }, c));
  tl.set(wmL, { opacity: 0, y: 60 }, 0);
  tl.to(wmL, { opacity: 1, y: 0, duration: 0.45, ease: "expo.out", stagger: 0.04 }, E.logoPop + 0.05);
  const tagl = el("div", "abs mono", world, {}, CFG.tool.tagline); tagl.id = "tagline";
  tl.set(tagl, { opacity: 0 }, 0);
  tl.fromTo(tagl, { opacity: 0, letterSpacing: "18px" }, { opacity: 1, letterSpacing: "6px", duration: 0.6, ease: "expo.out", immediateRender: false }, E.logoPop + 0.3);
  const dLogo = detBox(world, 300, 430, 480, 480, C.mint, CFG.tool.det);
  showDet(dLogo, E.detLogo);
  tl.to(dLogo.d, { opacity: 0, duration: 0.2 }, E.S7);
  const freeRow = el("div", "", world, { position: "absolute", left: "0", right: "0", top: "1170px", display: "flex", justifyContent: "center", gap: "16px", direction: "rtl" });
  const frees = CFG.tool.chips.map((h, k) => [h, k === 2 ? "font-size:26px" : ""]).map(([h, st], k) => {
    const c = el("div", "chip", freeRow, { position: "relative" }, h); if (st) c.style.cssText += st;
    if (k < 2) c.style.borderColor = `rgba(${aRGB},.5)`;
    tl.set(c, { opacity: 0, y: 30 }, 0);
    tl.to(c, { opacity: 1, y: 0, duration: 0.35, ease: "back.out(2)" }, E.freeChips + k * 0.18);
    return c;
  });

  // ---------- S7 categories + real capture ----------
  tl.to(frees, { opacity: 0, y: -20, duration: 0.2, stagger: 0.03 }, E.S7);
  tl.to(tagl, { opacity: 0, duration: 0.2 }, E.S7);
  tl.to(logo, { x: -150, y: -300, scale: 0.3, transformOrigin: "50% 50%", duration: 0.6, ease: "expo.inOut" }, E.S7);
  tl.to(wm, { x: 40, y: -605, scale: 0.42, duration: 0.6, ease: "expo.inOut" }, E.S7);
  const win = el("div", "glass", world, {}); win.id = "win";
  win.innerHTML = `<div class="tb"><i style="background:#ff5f57"></i><i style="background:#febc2e"></i><i style="background:#28c840"></i><span style="margin-left:14px">${CFG.capture.title}</span><span style="margin-left:auto;color:${C.red}">${CFG.capture.tag}</span></div>`;
  const realvid = document.getElementById("realvid");
  tl.set(win, { opacity: 0 }, 0);
  tl.fromTo(win, { opacity: 0, y: 60, scale: 0.94 }, { opacity: 1, y: 0, scale: 1, duration: 0.5, ease: "expo.out", immediateRender: false }, E.S7 + 0.1);
  tl.set(realvid, { opacity: 0 }, 0);
  tl.to(realvid, { opacity: 1, duration: 0.25 }, E.video + 0.1);
  const catRows = [el("div", "", world, { position: "absolute", left: "0", right: "0", top: "1290px", height: "70px", display: "flex", justifyContent: "center", gap: "14px", direction: "rtl" }),
    el("div", "", world, { position: "absolute", left: "0", right: "0", top: "1376px", height: "70px", display: "flex", justifyContent: "center", gap: "14px", direction: "rtl" })];
  const CATS = CFG.cats.map(([h, c]) => [/^[A-Za-z0-9 ]+$/.test(h) ? `<span class='lat'>${h}</span>` : h, role(c)]);
  const cats = CATS.map(([h, c], k) => {
    const d = el("div", "cat", catRows[k < 5 ? 0 : 1], { position: "relative" }, h);
    tl.set(d, { opacity: 0, scale: 0.6, y: 20 }, 0);
    tl.to(d, { opacity: 1, scale: 1, y: 0, color: C.ink, borderColor: c, backgroundColor: c.replace("#", "#") + "26", boxShadow: `0 0 26px ${c}55`, duration: 0.3, ease: "back.out(2.4)" }, E.cats[k]);
    return d;
  });
  const office = el("div", "glass", over, { left: "560px", top: "600px", width: "390px", height: "150px", borderRadius: "24px" });
  el("div", "lat", office, { position: "absolute", left: "30px", top: "22px", fontWeight: 700, fontSize: "32px" }, CFG.badge.title);
  const ostrike = el("div", "", office, { position: "absolute", left: "26px", top: "42px", height: "5px", width: "300px", background: C.red, borderRadius: "3px", transformOrigin: "0 50%" });
  const oneed = el("div", "", office, { position: "absolute", right: "30px", top: "82px", fontWeight: 800, fontSize: "34px", color: C.mint, direction: "rtl" }, CFG.badge.note);
  tl.set(office, { opacity: 0 }, 0); tl.set(ostrike, { scaleX: 0 }, 0); tl.set(oneed, { opacity: 0 }, 0);
  tl.fromTo(office, { opacity: 0, scale: 0.7, rotation: 6 }, { opacity: 1, scale: 1, rotation: -3, duration: 0.35, ease: "back.out(2)", immediateRender: false }, E.office - 0.35);
  tl.to(ostrike, { scaleX: 1, duration: 0.25, ease: "power2.out" }, E.office + 0.05);
  tl.to(oneed, { opacity: 1, duration: 0.2 }, E.office + 0.3);
  tl.to(office, { opacity: 0, scale: 0.9, duration: 0.25 }, E.cats[5] - 0.2);

  // ---------- S8 local ----------
  tl.to([win, realvid, office, ...cats, logo, wm], { opacity: 0, scale: "-=0.04", duration: 0.3, ease: "power2.in" }, E.S8);
  const lap = svg("svg", { id: "laptop", width: 600, height: 420, viewBox: "0 0 600 420" }, world);
  const scr = svg("path", { d: "M70 20 h460 a18 18 0 0 1 18 18 v292 h-496 v-292 a18 18 0 0 1 18 -18z", fill: "rgba(255,255,255,.04)", stroke: C.mint, "stroke-width": 5, pathLength: 1, "stroke-dasharray": "1 1" }, lap);
  const base = svg("path", { d: "M10 340 h580 l-30 50 h-520z", fill: "rgba(255,255,255,.04)", stroke: C.mint, "stroke-width": 5, pathLength: 1, "stroke-dasharray": "1 1", "stroke-linejoin": "round" }, lap);
  const rows = CFG.deviceRows.map(([n, o], k) => {
    const g = svg("g", { transform: `translate(110 ${70 + k * 82})` }, lap);
    const t1 = svg("text", { x: 0, y: 30, fill: C.ink, "font-family": "JBM", "font-size": 26 }, g); t1.textContent = n;
    const t2 = svg("text", { x: 380, y: 30, fill: C.mint, "font-family": "JBM", "font-size": 24, "text-anchor": "end" }, g); t2.textContent = o;
    svg("rect", { x: 0, y: 46, width: 380, height: 8, rx: 4, fill: "rgba(255,255,255,.1)" }, g);
    const bar = svg("rect", { x: 0, y: 46, width: 380, height: 8, rx: 4, fill: C.mint }, g);
    tl.set(g, { opacity: 0 }, 0); tl.set(bar, { scaleX: 0, svgOrigin: "0 50" }, 0);
    tl.to(g, { opacity: 1, duration: 0.2 }, E.laptop + 0.5 + k * 0.15);
    tl.to(bar, { scaleX: 1, duration: 0.7, ease: "power2.inOut" }, E.laptop + 0.6 + k * 0.2);
    return g;
  });
  tl.set([scr, base], { attr: { "stroke-dashoffset": 1 } }, 0);
  tl.to(scr, { attr: { "stroke-dashoffset": 0 }, duration: 0.6, ease: "power2.inOut" }, E.laptop);
  tl.to(base, { attr: { "stroke-dashoffset": 0 }, duration: 0.45, ease: "power2.inOut" }, E.laptop + 0.25);
  const cloud = el("div", "", world, { position: "absolute", left: "390px", top: "440px", width: "300px", height: "200px" });
  cloud.innerHTML = `<svg width="300" height="200" viewBox="0 0 300 200"><path d="M80 150 a50 50 0 0 1 8-99 a70 70 0 0 1 128 18 a42 42 0 0 1 6 81z" fill="rgba(255,255,255,.05)" stroke="rgba(${K.ink.replace("#", "").match(/../g).map((h) => parseInt(h, 16)).join(",")},.55)" stroke-width="5"/><path d="M150 190 v-80 m-24 24 l24 -24 l24 24" stroke="rgba(${K.ink.replace("#", "").match(/../g).map((h) => parseInt(h, 16)).join(",")},.55)" stroke-width="5" fill="none" stroke-dasharray="10 8"/></svg>`;
  const slash = el("div", "", cloud, { position: "absolute", left: "30px", top: "96px", width: "250px", height: "8px", borderRadius: "4px", background: C.red, transform: "rotate(-28deg)", transformOrigin: "0 50%", boxShadow: `0 0 18px rgba(${fRGB},.7)` });
  const nomatch = el("div", "mono", cloud, { position: "absolute", left: "-30px", top: "-46px", font: "500 22px/40px JBM", padding: "0 14px", background: C.red, color: K.bg, whiteSpace: "nowrap" }, CFG.cloudTag);
  tl.set(cloud, { opacity: 0 }, 0); tl.set(nomatch, { opacity: 0 }, 0);
  tl.fromTo(slash, { scaleX: 0 }, { scaleX: 1, duration: 0.25, ease: "power3.out", immediateRender: false }, E.cloudNo);
  tl.set(slash, { scaleX: 0 }, 0);
  tl.to(cloud, { opacity: 1, duration: 0.3 }, E.laptop + 0.3);
  tl.fromTo(nomatch, { opacity: 0, clipPath: "inset(0 100% 0 0)" }, { opacity: 1, clipPath: "inset(0 0% 0 0)", duration: 0.3, ease: "steps(10)", immediateRender: false }, E.cloudNo + 0.1);
  tl.set(lap, { opacity: 0 }, 0); tl.set(lap, { opacity: 1 }, E.laptop - 0.01);
  const NB = CFG.noBoxes;
  const noboxes = NB.map(([fa, en], k) => {
    const b = el("div", "nobox", world, { top: px(1150 + k * 104), color: C.red });
    el("div", "frame", b, { position: "absolute", inset: "0", border: "2px solid currentColor", borderRadius: "18px", background: `rgba(${fRGB},.08)` });
    el("div", "t", b, { color: C.ink }, fa);
    const m1 = el("div", "m mono", b, {}, `${en} · 0.97`);
    const m2 = el("div", "m mono", b, { color: C.mint }, `${en} · 0.00`);
    const st = el("div", "strike", b);
    const w = fa.length * 26 + 30;
    tl.set(b, { opacity: 0, x: 60 }, 0); tl.set(m2, { opacity: 0 }, 0); tl.set(st, { width: 0 }, 0);
    tl.to(b, { opacity: 1, x: 0, duration: 0.3, ease: "expo.out" }, E.strike[0] - 0.75 + k * 0.1);
    const t = E.strike[k];
    tl.to(st, { width: w, duration: 0.22, ease: "power2.out" }, t);
    tl.to(b, { color: C.mint, duration: 0.2 }, t + 0.05);
    tl.to(b.querySelector(".frame"), { backgroundColor: `rgba(${aRGB},.08)`, duration: 0.2 }, t + 0.05);
    tl.to(m1, { opacity: 0, duration: 0.1 }, t + 0.1); tl.to(m2, { opacity: 1, duration: 0.1 }, t + 0.15);
    return b;
  });

  // ---------- S9 CTA ----------
  tl.to([lap, cloud, ...noboxes], { opacity: 0, y: -30, duration: 0.3, ease: "power2.in", stagger: 0.03 }, E.S9);
  const ctaT = el("div", "abs", world, {}, `کامنت کن <span style="color:${C.mint}">«${CFG.cta.keyword}»</span>`); ctaT.id = "ctaTitle";
  const cbox = el("div", "glass", world, {}); cbox.id = "cbox";
  el("div", "av", cbox, {}, CFG.avatarInitial);
  const txt = el("div", "txt", cbox);
  const ph = el("span", "ph", txt, {}, CFG.cta.placeholder);
  const typed = el("span", "", txt, { color: C.ink });
  const caret = el("span", "", txt, { display: "inline-block", width: "4px", height: "54px", background: C.mint, verticalAlign: "middle", marginRight: "6px" });
  const send = el("div", "send", cbox, {}, `<svg width="88" height="88"><path d="M28 44 L62 28 L54 62 L46 48 Z" fill="${K.bg}"/></svg>`);
  const dm = el("div", "glass", world, {}); dm.id = "dm";
  el("div", "t", dm, {}, `${CFG.cta.dm} <span style="color:${C.mint}">✓✓</span>`);
  tl.set([ctaT, cbox, dm], { opacity: 0 }, 0);
  tl.fromTo(ctaT, { opacity: 0, y: 50, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.45, ease: "expo.out", immediateRender: false }, E.S9 + 0.05);
  tl.fromTo(cbox, { opacity: 0, y: 60 }, { opacity: 1, y: 0, duration: 0.45, ease: "expo.out", immediateRender: false }, E.S9 + 0.15);
  tl.to(caret, { opacity: 0, duration: 0.01, yoyo: true, repeat: 9, repeatDelay: 0.25 }, E.S9 + 0.2);
  // type the keyword letter by letter as growing prefixes (each prefix is shaped correctly by the browser)
  const kw = [...CFG.cta.keyword];
  kw.forEach((_, k) => tl.set(typed, { textContent: kw.slice(0, k + 1).join("") }, E.typing - 0.25 + k * Math.min(0.09, 0.36 / kw.length)));
  tl.set(typed, { textContent: "" }, 0);
  tl.set(ph, { display: "none" }, E.typing - 0.26);
  tl.to(send, { scale: 0.85, duration: 0.08, yoyo: true, repeat: 1 }, E.send);
  tl.to(send, { boxShadow: `0 0 40px rgba(${aRGB},.9)`, duration: 0.2, yoyo: true, repeat: 1 }, E.send);
  tl.fromTo(dm, { opacity: 0, y: 60, scale: 0.9 }, { opacity: 1, y: 0, scale: 1, duration: 0.4, ease: "back.out(1.8)", immediateRender: false }, E.dm);

  // ---------- S10 pixel monitor ----------
  const monL = document.getElementById("monLayer");
  const monBlack = el("div", "", monL, { position: "absolute", inset: "0", background: "#000" });
  tl.set(monBlack, { opacity: 1 }, 0); tl.set(monBlack, { opacity: 0 }, E.S1 + 0.2); tl.set(monBlack, { opacity: 1 }, E.mon[0] - 0.02);
  const mon = el("div", "", monL); mon.id = "mon";
  const monText = el("div", "", mon); monText.id = "monText";
  const MW = WORDS.filter((w) => w.p === E.TAIL).map((w) => w.w.replace(/[.…]/g, ""));
  const mws = MW.map((w, k) => {
    const g = el("div", "", monText, { position: "absolute", inset: "0", display: "flex", alignItems: "center", justifyContent: "center" });
    el("div", "mw", g, { color: "#ff3020", transform: "translateX(-7px)", mixBlendMode: "screen" }, w);
    el("div", "mw", g, { color: "#20d8ff", transform: "translateX(7px)", mixBlendMode: "screen" }, w);
    el("div", "mw", g, { color: "#ffffff" }, w);
    tl.set(g, { opacity: 0 }, 0);
    return g;
  });
  el("div", "", mon).id = "subpix";
  const glowL = el("div", "", mon); glowL.id = "monGlow";
  const glows = MW.map((w) => {
    const g = el("div", "", glowL, { position: "absolute", inset: "0", display: "flex", alignItems: "center", justifyContent: "center" });
    el("div", "mw", g, { color: `rgba(${aRGB},.9)`, filter: "blur(18px)" }, w);
    tl.set(g, { opacity: 0 }, 0);
    return g;
  });
  el("div", "focus", mon, { top: "0", WebkitMaskImage: "linear-gradient(#000 20%, transparent)", maskImage: "linear-gradient(#000 20%, transparent)" });
  el("div", "focus", mon, { bottom: "0", WebkitMaskImage: "linear-gradient(transparent, #000 80%)", maskImage: "linear-gradient(transparent, #000 80%)" });
  const crt = el("div", "", monL); crt.id = "crtLine";
  const showWords = (times) => times.forEach((t, k) => {
    const jx = ((k * 37) % 11) - 5, jy = ((k * 23) % 9) - 4, sc = CFG.monitorScale[k] || 1.2;
    tl.set(mws[k], { opacity: 1, x: jx * 3, y: jy * 3, scale: sc }, t);
    tl.set(glows[k], { opacity: 1, x: jx * 3, y: jy * 3, scale: sc }, t);
    if (k > 0) { tl.set(mws[k - 1], { opacity: 0 }, t); tl.set(glows[k - 1], { opacity: 0 }, t); }
  });
  // intro: the refrain on the monitor, then punch through the screen into the desktop
  tl.set(mon, { opacity: 1, scale: 1 }, 0);
  showWords(E.monIntro);
  tl.to(mon, { x: 14, duration: 0.03, yoyo: true, repeat: 3, ease: "none" }, E.S1 - 0.14);
  tl.to(mon, { scale: 3.2, opacity: 0, duration: 0.24, ease: "power3.in" }, E.S1 - 0.06);
  tl.set([...mws, ...glows], { opacity: 0 }, E.S1 + 0.2);
  // tail: same monitor, hard cut back in
  tl.set(mon, { opacity: 1, scale: 1, x: 0 }, E.mon[0] - 0.02);
  showWords(E.mon);
  tl.to(mon, { scaleY: 0.005, duration: 0.14, ease: "power3.in" }, E.crtOff);
  tl.set(crt, { opacity: 1 }, E.crtOff + 0.13);
  tl.to(crt, { scaleX: 0, duration: 0.2, ease: "power3.in" }, E.crtOff + 0.15);
  tl.to(crt, { opacity: 0, duration: 0.08 }, E.crtOff + 0.33);

  return tl;
};
