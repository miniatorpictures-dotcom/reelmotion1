/* ============================================================================
   reel.config.js — EVERYTHING brand- or product-specific lives here.
   main.js / events.js never contain copy, colours or product names.
   Example brand: kitchenatlas.studio (a Persian home-cooking channel) presenting
   "Measuro" (a fictional free, open-source recipe-unit converter).
   Replace every value marked {{...}} in the docs with your own.
   ============================================================================ */
window.CFG = {
  // ---------- identity ({{CREATOR_HANDLE}}, {{HUD_PREFIX}}, {{AVATAR_INITIAL}}) ----------
  creatorHandle: "kitchenatlas.studio",
  hudPrefix: "measuro/vision",
  avatarInitial: "K",

  // ---------- palette ({{BG_DEEP}} … {{TOOL_COLOR_3}}) ----------
  // Logic of the palette (keep the same number of colours):
  //   bg/bg2/ink/ink2/line = neutral base; accent = the one signature colour (success, highlights, progress);
  //   focus = the one warning colour (max ONE focus element per scene);
  //   ex1/ex2/ex3 = one colour per hook example; extra1..4 = variety for chips and categories;
  //   tool1..3 + toolIcon = the presented product's own brand colours (only in the reveal).
  colors: {
    bg: "#100c0a", bg2: "#221a16", ink: "#f6efe4", ink2: "rgba(246,239,228,.62)", line: "rgba(246,239,228,.16)",
    accent: "#ffc34d", accentRGB: "255,195,77", focus: "#e5533d", focusRGB: "229,83,61",
    ex1: "#ff9f43", ex2: "#6ab0ff", ex3: "#e86aa8",
    extra1: "#a58cf0", extra2: "#7c63c9", extra3: "#6fbf73", extra4: "#ff7a45",
    tool1: "#d9774b", tool2: "#b85a33", tool3: "#4c9a5b", toolIcon: "#ffe2cf",
  },
  // background colour-blob sets per scene (3 blobs each). Keys are scene names from events.js.
  blobs: {
    S1: ["rgba(255,159,67,.42)", "rgba(165,140,240,.38)", "rgba(106,176,255,.30)"],
    S2: ["rgba(106,176,255,.45)", "rgba(255,195,77,.25)", "rgba(165,140,240,.35)"],
    S3: ["rgba(232,106,168,.42)", "rgba(165,140,240,.38)", "rgba(255,159,67,.25)"],
    S4: ["rgba(255,195,77,.32)", "rgba(165,140,240,.40)", "rgba(232,106,168,.30)"],
    S5: ["rgba(229,83,61,.45)", "rgba(70,72,82,.45)", "rgba(120,30,30,.40)"],
    fuseHit: ["rgba(217,119,75,.55)", "rgba(76,154,91,.40)", "rgba(184,90,51,.45)"],
    S7: ["rgba(217,119,75,.45)", "rgba(255,195,77,.25)", "rgba(106,176,255,.30)"],
    S8: ["rgba(255,195,77,.38)", "rgba(111,191,115,.30)", "rgba(106,176,255,.28)"],
    S9: ["rgba(255,195,77,.40)", "rgba(165,140,240,.45)", "rgba(232,106,168,.30)"],
  },

  // ---------- which voice phrase plays which role (indices into timing.js PHR) ----------
  roles: {
    intro: 0,
    ex1: { say: 1, refrain: 2, result: 3 },
    ex2: { say: 4, refrain: 6 },
    ex3: { say: 7, refrain: 8 },
    payoff: 9, pros: [10, 11, 12],
    pain: { open: 13, limits: 14, l1: 15, l2: 16, l3: 17, shuffle: 18 },
    reveal: { name: 19, chips: 20 },
    cats: { first: 21 },
    local: { open: 30, nos: 31, last: 33 },
    cta: { say: 34, send: 35 },
    // tail = last phrase, always
  },
  // word anchors: [phraseIndex, substring of the word] (null word = phrase start)
  anchors: {
    e2Drop: [6, "همین"], e3Drop: [8, "×۱۰"],
    odoSpin: [9, "صد"], odoLand: [9, "واحد"],
    tabsMid: [13, "گشتن"], bars: [14, "دردسر"],
    fuse: [19, "ولی"], fuseHit: [19, "اسمش"], logoPop: [19, "مژرو"],
    cats: [[21, null], [22, null], [23, null], [24, null], [25, null], [27, "دما"], [27, "زمان"], [27, "وزن"], [28, "قاشق"], [29, null]],
    badge: [26, "اینترنت"], cloudNo: [30, "انجام"],
    strike: [[31, "تبلیغی"], [31, "محدودیت"], [33, "ثبت"]],
    typing: [34, "«پیمانه»"],
  },

  // ---------- S1–S3 hook examples ----------
  keyLabel: "Hold",
  examples: [
    { chipIn: "CUP", chipOut: "GRAM", color: "ex1", file: ["brownie", ".recipe"], thumb: "image", payoff: "flash",
      det: "cups · 3 items · 0.98", detOut: "grams · converted · 0.12s", center: ["3 × CUP", "Drop → GRAM"],
      labels: [["GRAM", "weight"], ["ML", "volume"], ["OZ", "imperial"], ["TBSP", "spoon"], ["TSP", "spoon"], ["LB", "imperial"], ["KG", "weight"], ["L", "volume"]],
      image: ["#ffcf8a", "#e8894f", "#8a4a2b", "#3a1d12"] },
    { chipIn: "°F", chipOut: "°C", color: "ex2", file: ["oven", ".note"], thumb: "doc", payoff: "stamp", stamp: "°C",
      det: "°F · oven · 0.97", detOut: "°C · 177° · 0.05s", center: ["350 °F", "Drop → °C"],
      labels: [["°C", "celsius"], ["GAS", "mark"], ["K", "kelvin"], ["FAN", "−20°"], ["°F", "fahrenheit"], ["MIN", "time"], ["H", "time"], ["SEC", "time"]] },
    { chipIn: "×4", chipOut: "×10", color: "ex3", file: ["tahdig", ".recipe"], thumb: "media", payoff: "bars",
      det: "servings: 4 · 0.99", detOut: "servings: 10 · scaled · 0.02s", center: ["4 servings", "Drop → ×10"],
      labels: [["×10", "guests"], ["×2", "double"], ["×6", "party"], ["×8", "family"], ["×1", "solo"], ["×12", "feast"], ["½", "half"], ["×3", "small"]] },
  ],

  // ---------- S4 payoff ----------
  wall: ["GRAM", "KG", "MG", "OZ", "LB", "CUP", "TBSP", "TSP", "ML", "L", "FL OZ", "PINT", "QUART", "°C", "°F", "GAS", "PINCH", "DASH", "STICK", "CAN", "SLICE", "CLOVE", "HANDFUL", "SCOOP",
         "MIN", "HOUR", "×2", "×4", "×10", "½", "¼", "⅓", "KCAL", "KJ", "CM", "INCH", "TRAY", "PAN", "MUG", "GLASS", "SPOON", "DROP", "BUNCH", "NOB", "SPRIG", "PACK"],
  odometer: { digits: [1, 2, 0], label: 'واحد <span style="opacity:.45;font-weight:500"> · ۹ دسته</span>' },
  pros: ["رایگان", "روی گوشی خودت", "بدون تبلیغ"],

  // ---------- S5 pain ----------
  tabs: {
    domains: ["unit-convert-free.xyz", "cups2grams-pro.site", "best-kitchen-calc.top", "convert-recipe-24.net", "measurehub.biz"],
    title: "Recipe Unit Converter", button: "CONVERT",
    ads: [
      [["DOWNLOAD NOW", "#ffd84a", 30, 380, 330, 80], ["WIN!", "#ff5ca8", 520, 30, 200, 150]],
      [["▶ PLAY", "#5bf07a", 500, 340, 220, 110], ["UPGRADE PRO", "#ffb547", 30, 30, 300, 70]],
      [["SIGN UP", "#ff8a4c", 470, 30, 250, 70], ["FREE*", "#5bd4ff", 30, 360, 200, 100]],
      [["50% OFF", "#ff5ca8", 30, 30, 240, 90], ["DOWNLOAD", "#ffd84a", 420, 370, 300, 80]],
      [["CLICK HERE", "#5bf07a", 30, 380, 300, 80], ["PREMIUM", "#ffb547", 470, 30, 250, 80]],
    ],
  },
  barsWord: "دردسر",
  painBoxes: ["ads: 14 · 0.97", "missing: 3 units · 0.95", "signup_required · 0.99"],
  wastedLabel: "time wasted",
  wastedSeconds: 292,

  // ---------- S6 reveal ----------
  tool: {
    wordmark: "Measuro", tagline: "DRAG · DROP · MEASURED",
    det: "tool: MEASURO · free · open-source · 0.99",
    logoSegments: ["tool1", "tool3", "tool1", "tool2", "tool1", "tool2", "tool2"], logoAccentIndex: 1,
    chips: ["رایگان", "متن‌باز · <span class='lat'>MIT</span>", "<span class='lat'>Android · iOS · Web</span>"],
  },

  // ---------- S7 categories + real capture ----------
  capture: { title: "Measuro · Android", tag: "● real capture", playbackRate: 0.85, sourceSeconds: 8.4 },
  cats: [["آرد", "ex1"], ["شکر", "focus"], ["کره", "ex2"], ["شیر", "extra3"], ["ادویه", "extra4"], ["دما", "ex3"], ["زمان", "extra1"], ["وزن", "accent"], ["قاشق", "ex2"], ["پیمانه", "ex1"]],
  badge: { title: "Wi-Fi", note: "لازم نیست ✓" },

  // ---------- S8 local ----------
  deviceRows: [["brownie.recipe", "→ grams"], ["oven.note", "→ °C"], ["tahdig.recipe", "→ ×10"]],
  cloudTag: "upload: NO MATCH",
  noBoxes: [["تبلیغ", "ads"], ["محدودیت تعداد", "daily_limit"], ["ثبت‌نام", "signup"]],

  // ---------- S9 CTA ----------
  cta: { keyword: "پیمانه", placeholder: "یه کامنت بنویس…", dm: "لینکش رو برات فرستادم" },

  // ---------- monitor (intro + tail refrain) ----------
  monitorScale: [0.78, 1.0, 1.3, 1.45],
};
