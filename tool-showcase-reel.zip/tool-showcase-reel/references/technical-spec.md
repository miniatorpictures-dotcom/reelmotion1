# Technical spec — tool-showcase reel

All values are the ones used in the shipped reference implementation (`assets/composition/*`). Identity values are variables (`{{UPPER_SNAKE_CASE}}`) set in `reel.config.js`.

## 1. Output
| Item | Value |
|---|---|
| Canvas | 1080 × 1920 px (9:16) |
| Frame rate | 30 fps |
| Duration | `EV.DUR` = last phrase end + 0.12 s (CRT-off start) + 0.55 s ≈ 60 s for a 37-phrase script |
| Video codec | H.264 (HyperFrames `-q delivery`), `--video-frame-format png` for the screen capture |
| Audio | AAC from `audio/mix.wav` (48 kHz stereo, −14 LUFS integrated, ≤ −1 dBTP) |
| Render engine | HyperFrames 0.8.181 (`npx hyperframes render`), Chromium headless shell, GSAP 3.x (local `assets/gsap.min.js`) |
| Render time (2 vCPU, software GL, screenshot capture) | ≈ 5 min capture + 2 min encode for 60 s |

## 2. Layer stack (bottom → top, all `position:absolute; inset:0` unless noted)
1. `#bg` — `radial-gradient(90% 60% at 80% 0%, {{BG_2}} 0%, {{BG_DEEP}} 60%)`
2. `#blobs` — 3 discs 1100 × 1100 px, `opacity .55`, fill `radial-gradient(circle, var(--cN) 0%, transparent 62%)`; colours from `CFG.blobs[scene]`, cross-fade 0.6 s `sine.inOut` starting 0.1 s before each scene. Drift (pure function of time t): x = [−250, 420, 80][i] + sin(0.35 t + 2.1 i)·140, y = [−200, 650, 1300][i] + cos(0.28 t + 1.3 i)·160.
3. `#grid` — 90 px squares, 1.5 px white lines, `opacity .07`, inset −60 px, scrolls `translateY((6 t) mod 90)`.
4. `#world` — all scene content (cards, ring, tabs, logo, …).
5. `<video id="realvid">` — the real capture (sibling ABOVE `#world`, so overlays that must cover it go to `#over`).
6. `#over` — light streaks, flash, floating badge.
7. `#cap` — captions (left/right 70 px, top 1505 px, height 260 px, `direction:rtl`).
8. `#hud` + `#hudline` + `#prog` — HUD and progress bar.
9. `#grain` — SVG `feTurbulence` fractalNoise baseFrequency .85, 3 octaves, seed 4, desaturated, 1280 × 2120, `opacity .13`, `mix-blend-mode: overlay`, jittered every frame through 6 offsets x [0, −37, 21, −64, 48, −12], y [0, 29, −51, 13, −33, 57].
10. `#vignette` — `radial-gradient(120% 85% at 50% 45%, transparent 55%, rgba(0,0,0,.62) 100%)`.
11. `#monLayer` — black backdrop + pixel monitor (intro and tail only).

## 3. Tokens (example values in brackets; logic in reel.config.js)
| Variable | Role | Example | Original-build logic |
|---|---|---|---|
| `{{BG_DEEP}}` | base background | #100c0a | near-black, slightly tinted |
| `{{BG_2}}` | top-right glow of the bg gradient | #221a16 | 1 step lighter than BG_DEEP |
| `{{INK}}` | text | #f6efe4 | warm off-white; secondary = INK @ .62, lines = INK @ .16 |
| `{{ACCENT}}` | the ONE signature colour (success, highlights, progress, captions keywords) | #ffc34d | bright, high-contrast on BG |
| `{{FOCUS}}` | the ONE warning colour (pain, errors, strike) — max one focus element per scene | #e5533d | warm red |
| `{{EX1_COLOR}}` `{{EX2_COLOR}}` `{{EX3_COLOR}}` | one colour per hook example (chip, detection box, blob) | #ff9f43 #6ab0ff #e86aa8 | warm / cool / pink — three clearly different hues |
| `{{EXTRA_1..4}}` | variety for wall chips and categories | #a58cf0 #7c63c9 #6fbf73 #ff7a45 | |
| `{{TOOL_COLOR_1..3}}`, `{{TOOL_ICON_COLOR}}` | the presented product's brand colours (reveal only) | #d9774b #b85a33 #4c9a5b #ffe2cf | sampled from the product's own logo |

Glass material (`.glass`): background `linear-gradient(155deg, rgba(255,255,255,.16), rgba(255,255,255,.04) 42%, rgba(255,255,255,.08))`; `backdrop-filter: blur(22px) saturate(1.5)`; border 1.5 px rgba(255,255,255,.2); radius 34 px; shadows `inset 0 1.5px 0 rgba(255,255,255,.4), inset 0 -24px 48px rgba(255,255,255,.035), -1.5px 0 0 rgba(255,90,90,.18), 1.5px 0 0 rgba(90,220,255,.18), 0 40px 90px rgba(0,0,0,.55)`; `::before` highlight `radial-gradient(120% 70% at 10% -10%, rgba(255,255,255,.22), transparent 50%)`. The ±1.5 px red/cyan shadows fake chromatic aberration at the rim.

## 4. Typography
| Use | Family | Weight | Size / line-height |
|---|---|---|---|
| Captions (Persian) | `{{FONT_FA}}` (family name "FA"; files `assets/fonts/fa-{300,500,700,800,900}.woff2`; default Vazirmatn; original Peyda) | 800 | 60 px / 1.45, word gap 7 px each side |
| Captions (Latin words) | Sora | 700 | 56 px |
| Big kinetic word (bars) | FA | 900 | 210 px |
| Odometer digits (Persian digits ۰–۹) | FA | 900 | 170 px in 150 × 190 px wheels |
| CTA title | FA | 900 | 128 px |
| Monitor words | FA | 900 | 360 px × per-word scale `CFG.monitorScale` = [0.78, 1.0, 1.3, 1.45] |
| Wordmark | Sora | 800 | 150 px, letter-spacing −3 px |
| HUD / tags / code | JetBrains Mono ("JBM") | 400/500 | 22 px (HUD), 22 px/40 px (tags) |
| HUD brand | Sora | 600 | 25 px |
| Chips | FA 700 34 px (glass chip), Sora 700 25 px (format chip), FA 700 32 px (category) |

Rules: Latin words in Persian text are wrapped in `.lat` (Sora, `direction:ltr; unicode-bidi:isolate`); trailing Persian punctuation (، ؛ ؟ . ! …) is kept OUTSIDE the isolated span. Never animate Persian per letter (joins break) — animate whole words; per-letter only on Latin (wordmark).

## 5. Global elements
- HUD: left 64, right 64, top 66, height 40; text `{{CREATOR_HANDLE}}` (left), `● {{HUD_PREFIX}} · f NNNN · obj N` (right, mono 22 px, ink @ .5, red dot 10 px with glow). Frame counter = round(t·30). Object count by scene: 1 (S1–S3), 48 (S4), 5 (S5), 1 (reveal–S7), 3 (S8), 1 (S9+). Line under HUD at top 118, 1.5 px.
- Progress bar: left/right 64, bottom 54, height 5, radius 3, track white @ .08, fill ACCENT with `0 0 14px` glow, `scaleX 0→1` linear over DUR.
- Captions: one `.capline` per caption line; in at `line.s − 0.05` (opacity 0→1, y 18→0, 0.18 s `power3.out`), out at `min(next.s − 0.16, line.e + 0.9)` (opacity →0, y →−10, 0.10 s `power2.in`). Each word starts at opacity .3 and jumps to 1 (0.08 s) at its start time; keywords tween colour ink→role colour and scale 1.12→1 (0.25 s `back.out(2)`). Caption layer hidden during intro (until S1 − 0.01) and tail (from first tail word − 0.02).
- Detection box (`detBox`): 4 corner brackets 44 × 44 px, 4 px borders, plus a 1.5 px frame at .35; tag above (height 40, mono 500 22 px/40, padding 0 14, text BG colour on box colour). Show = opacity 0→1 + scale 1.14→1 (0.32 s `expo.out`), tag revealed with `clip-path inset(0 100% 0 0)→inset(0 0 0 0)` in 0.35 s `steps(12)` starting +0.08 s.

## 6. Scene timing (formulas — P = phrase list of timing.js, roles from CFG.roles)
| Scene | Start | Content |
|---|---|---|
| intro (monitor) | 0 | refrain words on the pixel monitor |
| S1 example 1 | P[ex1.say].t0 − 0.32 | card + ring + drop |
| S2 example 2 | P[ex2.say].t0 − 0.16 | whip, card 2 |
| S3 example 3 | P[ex3.say].t0 − 0.19 | whip, card 3 |
| S4 payoff | P[payoff].t0 − 0.20 | zoom out, wall, odometer, 3 pro chips |
| S5 pain | P[pain.open].t0 − 0.25 | browser tabs, bars word, 3 red boxes, shuffle |
| S6 reveal | P[reveal.name].t0 − 0.22 | fuse → flash → logo, wordmark, chips |
| S7 categories | P[cats.first].t0 − 0.21 | real capture window + category chips + badge |
| S8 local | P[local.open].t0 − 0.22 | device outline, cloud NO MATCH, 3 struck boxes |
| S9 CTA | P[cta.say].t0 − 0.20 | title, comment box typing, DM bubble |
| S10 tail | P[last].t0 − 0.12 | monitor again, CRT power-off |

Derived events (events.js): e1In = S1+0.02; e1Ctrl = P[ex1.refrain].t0−0.05; e1Drop = P[ex1.result].t0+0.02; e2In = S2+0.08; e2Ctrl = P[ex2.refrain].t0−0.05; e2Drop = anchor e2Drop+0.05; e3In = S3+0.08; e3Ctrl = P[ex3.refrain].t0−0.05; e3Drop = anchor e3Drop−0.05; burst = P[payoff].t0+0.2; odoSpin = anchor−0.15; odoLand = anchor; chips 1–3 = P[pros[k]].t0; tabs = [P[pain.open].t0, +0.55, tabsMid, tabsMid+0.45, tabsMid+0.9]; bars = anchor−0.05; barsOut = P[l1].t0−0.12; box1–3 = P[l1..l3].t0; shuffle = P[pain.shuffle].t0 + [0.3, 1.05, 1.8, 2.75, 3.3]; fuse = anchor; fuseHit = anchor−0.05; logoPop = anchor−0.05; detLogo = logoPop anchor+0.35; video = S7+0.19; crtOff = P[last].t1+0.12.

## 7. Element animation details
### Intro / tail — pixel monitor
- Black backdrop on (intro from 0, off at S1+0.2; tail on at first tail word −0.02).
- Each word = 3 stacked copies (red #ff3020 at x −7 px and cyan #20d8ff at x +7 px with `mix-blend-mode:screen`, white on top) + glow copy (ACCENT @ .9, `blur(18px)`, layer `screen` .55).
- Subpixel overlay `#subpix` (`mix-blend-mode:multiply`, bg black): three radial capsules 4 × 11 px at x 5/14/23, y 14, colours #ff8a7a / #9affb0 / #8aa8ff, tile 28 × 28 px.
- Focus fall-off: two 640 px bands top/bottom with `backdrop-filter: blur(7px)` masked by linear gradients (#000 20 % → transparent).
- Hard cut per word at its start time; offset per word k: x = (((37k) mod 11) − 5)·3 px, y = (((23k) mod 9) − 4)·3 px; scale = monitorScale[k].
- Intro exit: shake x ±14 px (0.03 s ×4) at S1−0.14, then `scale 1→3.2, opacity 1→0` in 0.24 s `power3.in` at S1−0.06 ("punch through the screen").
- Tail exit (CRT off) at crtOff: `scaleY 1→0.005` 0.14 s `power3.in`; white line (top 955, height 10, #e9fff8, glow ACCENT 40 px) appears at +0.13, `scaleX →0` 0.2 s `power3.in` at +0.15, fades 0.08 s at +0.33.

### S1–S3 hook examples
- Strip 3240 × 1920 (3 panels × 1080) holds the cards; whip = `x −1080·k` in 0.36 s `power4.inOut` starting at scene start −0.18, plus 9 light streaks in `#over` (top 260+150 j + rand·60, width 700–1300, height 2–7 px, gradient transparent→colour→transparent, colours cycle EX1, EX2, EX3, ACCENT, white) sweeping x 1300→−1500 in 0.3 s `power2.inOut`, staggered 0.012 s. NO CSS blur on the strip (blank frames in software GL).
- Card: glass 420 × 470 at (330, 330), padding 26; thumbnail 368 × 300 radius 22; filename Sora 600 30 px at left 30 / bottom 44; type chip 54 px high, min-width 110, radius 14, Sora 800 28 px, at right 26 / bottom 34. Example 1 enters: opacity 0→1, y 90→0, scale .9→1, rotationX 14→0 (perspective 900), 0.6 s `expo.out`; examples 2–3 are already visible on their panel and pop scale .92→1 (0.5 s `back.out(2)`) at eIn−0.05.
- Detection box around the card: (296, 296) 488 × 538, colour = example colour, shown at eIn+0.28.
- Key chip (example 1 only): glass at (690, 790), height 66, radius 16, Sora 700 30 px, text `{{KEY_LABEL}}`; in at eCtrl−0.1 (opacity, scale .6→1, 0.3 s `back.out(2.4)`), press at eCtrl+0.25 (scale .9, y +6, 0.08 s yoyo), out at eDrop+0.1.
- Cursor (64 px SVG arrow, white, 3 px dark stroke, origin 10 6): appears at (980, 1660) at T−0.12; to (560, 580) 0.4 s `power3.out` at T−0.1; press scale .82 at T+0.3; card dims to opacity .5 / scale .97; ghost thumbnail (150 × 124, radius 20, border 2 px white @ .55) appears at (470, 520) scale .6→1, rotation −6 (0.18 s `back.out(2)`) at T+0.33; cursor → (548, 1092) 0.5 s `power2.inOut` at T+0.38, ghost → (488, 1030) at T+0.4.
- Ring (600 × 600 at (240, 800), centre (540, 1100)): glass ring via `backdrop-filter: blur(16px) saturate(1.5)` masked to radii 104–298 px; 8 SVG sectors, inner radius 108, outer 294, 45° each minus 1.6° gap each side, fill rgba(20,20,28,.42), stroke white @ .16 1.5 px; labels at radius 200 (Sora 700 30 px + mono 17 px subtitle). Centre disc: glass 220 px, text `1 × IN / Drop → OUT`. Opens at T+0.58: opacity 0→1, scale .55→1, rotation −25→0, 0.45 s `back.out(1.5)`; sectors fade in stagger .025; labels opacity/scale .7→1 stagger .03 `back.out(2)` at T+0.68.
- Hover: at max(T+1.0, eDrop−0.45) cursor moves to the centre of sector 0 (radius 200, angle −67.5°) in 0.32 s, ghost follows; sector highlight (fill `{{EXTRA_1}}`) fades in 0.12 s at +0.22.
- Drop at eDrop: highlight turns ACCENT (0.08 s), ghost scale→.2/opacity 0 (0.2 s `power2.in`), ring scale 1.08/opacity 0 (0.24 s `power2.in`) at +0.06; cursor exits to (900, 1300) at +0.25; card back to full; input chip flies out (y −46, rotation −10, 0.24 s `power2.in`) at +0.08; output chip (ACCENT) pops in (y 40→0, scale .6→1, 0.36 s `back.out(2.2)`) at +0.16 — for payoff "stamp" it unfolds instead (rotationX −95→0, origin top, perspective 500, 0.45 s `back.out(1.8)`); check badge (64 px ACCENT circle, top-right −22 px) pops (scale 0→1, 0.35 s `back.out(3)`) at +0.24; input detection box fades (0.12 s) and output box (ACCENT) shows at +0.2.
- Payoff per example: `flash` = white overlay on thumbnail .85 for 0.05 s then fades 0.4 s; `stamp` = dog-ear corner 86 px (linear-gradient 225° BG 50 % / #d7d9e2 50 %, scale 0→1 0.3 s `power3.out` at +0.12) + stamp text (4 px FOCUS border, Sora 800 34 px) from scale 2.2/rotation −14 to 1/−8 in 0.3 s `power4.in` at +0.22; `bars` = 26 bars 7 px wide every 12.6 px (heights 30 + |sin(0.7k)·120|·(0.5+rand·0.6)), scaleY 0→1 0.4 s `back.out(2)` stagger 0.018 from centre at +0.14, then breathe scaleY .55 yoyo ×3 (0.3 s `sine.inOut`) at +0.6.

### S4 payoff
- Strip zooms out at S4: x −1080, y −560, scale .3 (origin 1620 960) in 0.7 s `expo.inOut` → three finished cards become a mini row at the top.
- Wall: `CFG.wall` (up to 46 chips) on a jittered grid — 3 rows × 6 at y 470 + 62 r, 4 rows × 6 at y 1200 + 64 r (x 110 + 172 c + 60·(r mod 2)), plus 8 side slots (x 60 / 1020, y 700 + 110 r); jitter ±20 px x, ±9 px y. Each flies from the centre (540, 830) at scale .3 to its slot: opacity .32–.82, scale .75–1.1, rotation ±8°, 0.8–1.1 s `expo.out`, stagger 0.012 from burst; then drifts ±20/±15 px over 5 s `sine.inOut`.
- Odometer: glass 700 × 360 at (190, 650); 3 wheels 150 × 190 at x 40/220/400, each a column of 30 digits; spins to digit `d` of the third cycle: y = −(20 + d)·190, durations 0.75/0.93/1.11 s `power3.out`, starts odoSpin + 0.05 k. "+" ACCENT FA 900 120 px at (590, 92); label below at top 268 (FA 700 40 px). Card in at burst−0.1 (opacity, scale .85→1, y 40→0, 0.5 s `back.out(1.6)`); glint sweep xPercent −120→120 (0.7 s) at odoLand+0.15.
- Pro chips row at top 1060, gap 18: each opacity/y 30→0/scale .8→1 (0.35 s `back.out(2.2)`) at P[pros[k]].t0, ACCENT bullet ●.
- Exit at S5: odometer and chips out, wall chips fall y +420, rotation +25°, 0.55 s `power2.in`, random stagger 0.004.

### S5 pain
- 5 fake browser tabs 780 × 560 (radius 26, #16171b, url bar 70 px #202127, url pill 42 px mono 21 px) at [(150,470,−4°), (130,640,3°), (160,560,−2°), (140,740,4°), (150,620,−1°)]; content: title Sora 800 40 px, blue CONVERT button 400 × 86, spinner (rotates 14 turns over 13 s), 2 flashing ads per tab (`steps(1)` opacity .35 yoyo ×17). In at E.tabs[k]: y 140→0, scale .88→1, rotation 2r→r, 0.5 s `back.out(1.4)`. The tabs wrapper MUST have `z-index:0`.
- Bars word: tabs dim to .22 at bars−0.15; word (FA 900 210 px FOCUS, glow) scale 1.3→1 0.25 s `expo.out` at bars−0.12; 7 steel bars (26 × 560, x 178 + 116 k, top 560, metallic gradient) drop from y −1300 with `bounce.out` 0.42 s stagger 0.035; world shake x 10 px (0.05 s ×6) at bars+0.36; all out at barsOut.
- Red detection boxes on the tabs at box1–3 (rects (150,610,560,210), (420,900,520,210), (170,1150,640,200)), each flickers 4× (`steps(1)`) at +0.32; all fade at shuffle[0]−0.15.
- "time wasted mm:ss" mono FOCUS at right 90 / top 170, counts 0→`CFG.wastedSeconds` (292) with `power2.in` from tabs[2] to S6.
- Shuffle: at each shuffle time the front tab flies out x ±760, rotation ±14°, 0.24 s `power3.in`, goes to the back (z-index), returns 0.3 s `power3.out` at opacity .85.

### S6 reveal
- Fuse path `M860,1470 C1000,1300 160,1260 250,1060 C320,900 520,980 540,700` (starts near the first caption word, ends above centre): rope 9 px #b9a88a dash 14/9; ash 12 px #1a1a1d drawn behind the spark; spark = glow circles r 70/30/11 + 8 rays, rotating 1400°·p. Burn p 0→1 from fuse to fuseHit with `power1.in`.
- fuseHit: white radial flash .95 (0.06 s) then 0.5 s fade; tabs blow out radially (900 px, rotation (k−2)·25°, scale 1.3, opacity 0, 0.55 s `power3.out`).
- Logo placeholder: 7 ring segments (360/7° each, gap 2.6°, radii 92–190, accent segment +12 px) in tool colours; segments scale 0→1 rotation −60→0 (svgOrigin 200 200) 0.55 s `back.out(1.6)` stagger 0.05; accent segment last at logoPop (`back.out(3)`) with glow pulse; file icon rises 0.35 s at fuseHit+0.25.
- Wordmark letters y 60→0 stagger 0.04 (0.45 s `expo.out`) at logoPop+0.05; tagline letter-spacing 18→6 px (0.6 s) at +0.3; ACCENT detection box around the logo (300, 430, 480 × 480) tag `{{TOOL_DET}}` at detLogo; chips row at top 1170 stagger 0.18 from P[reveal.chips].t0.

### S7 categories + real capture
- Logo → x −150, y −300, scale .3; wordmark → x 40, y −605, scale .42 (0.6 s `expo.inOut`) = small lockup at the top.
- Window: glass 900 × 800 at (90, 455), title bar 64 px (traffic lights, `{{CAPTURE_TITLE}}`, FOCUS "● real capture"); capture video 860 × 696 at (110, 539), playbackRate 0.85, fades in at video+0.1.
- Category chips: 2 rows (top 1290 and 1376, gap 14, 5 per row), each pops (scale .6→1, y 20→0, 0.3 s `back.out(2.4)`) and lights in its colour (border colour, bg colour + `26` alpha, glow `0 0 26px colour55`) at its anchor.
- Badge (in `#over`): glass 390 × 150 at (560, 600), title Sora 700 32 px, FOCUS strike line 300 × 5 drawn 0.25 s at badge+0.05, note ACCENT FA 800 34 px at +0.3; enters at badge−0.35 (scale .7→1, rotation 6→−3); leaves before the 6th category.

### S8 local
- Everything of S7 fades (0.3 s) at S8. Device outline (600 × 420 SVG at (240, 700), ACCENT 5 px strokes) draws with `pathLength=1` dash offset 1→0 (screen 0.6 s, base 0.45 s); 3 file rows (mono 26 px name, ACCENT target) fade in stagger 0.15 from laptop+0.5, progress bars fill 0.7 s stagger 0.2.
- Cloud (300 × 200 at (390, 440)) with dashed up-arrow; FOCUS slash 250 × 8 rotated −28° grows at cloudNo; tag `{{CLOUD_TAG}}` types in (steps 10).
- 3 boxes 780 × 92 at (150, 1150 + 104 k): FOCUS frame + Persian label (FA 800 40 px) + mono `name · 0.97`; slide in from x 60 before the first strike; at each strike: ACCENT line draws under the label (width = letters·26+30 px, 0.22 s), box colour → ACCENT, mono → `name · 0.00`.

### S9 CTA
- Title "کامنت کن «{{CTA_KEYWORD}}»" FA 900 128 px at top 560 (in 0.45 s `expo.out`); comment box glass 880 × 130 radius 65 at (100, 820): avatar 88 px (gradient ACCENT→FOCUS, `{{AVATAR_INITIAL}}`), placeholder text, typed keyword as growing prefixes (≤ 0.09 s per letter), blinking caret (ACCENT 4 × 54), send button 88 px ACCENT pulses at send; DM bubble glass 720 × 120 (radius 36 36 36 8) at (180, 1010) pops at dm.

## 8. Audio spec
| Stage | Value |
|---|---|
| Voice cut detection | silencedetect −38 dB, d 0.12 s |
| Boundary refine | 5 ms envelope; tail extended until < −52 dBFS (max +0.35 s) +0.03 s; head pulled back until < −52 dBFS (max −0.15 s) −0.02 s |
| Pause inside a section | ≤ 0.24 s; section gaps from takes.json (0.12–0.65 s) |
| Gap fill | room tone from the raw file × 0.9, crossfades 8 ms |
| Raw chain | highpass 80 Hz → afftdn nr 8 nf −62 → EQ −2.5 dB @ 210 Hz (Q≈1.1) → +2.5 dB @ 3.5 kHz → high-shelf +2 dB @ 10 kHz → de-esser 0.35 → comp −22 dB 3:1 6/120 ms +3 dB → atempo 1.1 → loudnorm −16 LUFS / −2 dBTP / LRA 8 |
| Enhanced chain | +10 % small-room convolution (reflections 7/11/17/23/31 ms) + room tone −64 dB → highpass 75 → afftdn nf −32 nr 5 → −2 dB @ 220 Hz → +1 dB @ 3.2 kHz → shelf −2.5 dB @ 9 kHz → de-esser 0.3 → comp −20 dB 2.5:1 8/140 ms +2 dB → atempo 1.1 → −16 LUFS |
| SFX normalisation | each sample: loudest 100 ms = −12 dB RMS; then per-cue gain −4…−18 dB (cue sheet in tools/sfx_mix.py) |
| Ducking | SFX −4.5 dB × speech activity (voice 30 ms RMS mapped −40…−25 dB → 0…1, instant attack, 120 ms release) |
| Stems | voice ≈ −16 LUFS, SFX ≈ −24 LUFS |
| Master | comp −18 dB 2:1 15/200 ms +1 dB → limiter 0.89 → loudnorm −14 LUFS / −1 dBTP / LRA 10 |
| Music | none in the file; user adds in the Instagram editor at 15–25 %, lift on the reveal |
