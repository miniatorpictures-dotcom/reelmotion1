# Step-by-step build process

Project folder layout after `scripts/setup.sh <project>`:
```
<project>/
  index.html  main.js  events.js  reel.config.js  timing.js (generated)
  assets/  gsap.min.js  fonts/  video/real.mp4
  audio/   raw.wav  takes.json  script.json  sfx_map.json  phrases_raw.json  vo.wav  ev.json  premix.wav  mix.wav
  tools/   asr_chunks.py asr_phrases.py edit_vo.py voice_chain.sh make_timing.py sfx_mix.py master.sh dump_events.js sync_durations.js render.sh make_placeholder_capture.sh
  renders/
```

## 1. Research the references (30–60 min)
1. For each reference reel: `ffmpeg -i ref.mp4 -vf "fps=16/<duration>,scale=360:-1,tile=4x2" grid_%02d.jpg` → look at the grids.
2. Note: format (talking head / pure motion), chapters, hook, CTA keyword, visual language, what makes it work, what is weak (e.g. "no human face").
3. For the reel you localise, extract its text: `ffmpeg -i ref.mp4 -vf "fps=2,crop=iw:ih*0.14:0:ih*0.67,scale=540:-1,tile=2x12" cap_%02d.jpg` (adjust the crop to the caption band).
4. Fact-check the product on its official site: number of formats/units, platforms, price, offline, requirements. Write the facts down with the date.

## 2. Write the scenario (fixed 11-beat structure)
| # | Beat | Duration target | Content rule |
|---|---|---|---|
| 0 | Cold open | 1.2–1.5 s | the refrain only, on the pixel monitor |
| 1–3 | Three examples | 3–5 s each | "Got X? Drag it, drop it in here… now Y." Escalate (simple → impressive). Same rhythm each time. Tool name NOT said. |
| 4 | Payoff | 5–7 s | "and just like that, more than N …; free, on your own device, no limits" (honest wording) |
| 5 | Pain | 10–13 s | the ridiculous old way; 3 concrete limits (said as «یکی … یکی … یکی …»); "from this page to that page" |
| 6 | Reveal | 3–4 s | «ولی این ابزار… اسمش {{TOOL_NAME_FA}}‌ئه. رایگان و متن‌باز.» |
| 7 | Categories | 8–10 s | 10 categories in 5 short phrases, one surprising "without even …" |
| 8 | Local / proof | 5–6 s | answers the 3 pain limits one by one («نه … نه … نه …») |
| 9 | CTA | 2.5–3 s | «کامنت کن «{{CTA_KEYWORD}}» تا لینکش رو برات بفرستم.» |
| 10 | Tail | 1.2 s | the refrain again |
Use `assets/templates/script-template.md`. Total ≈ 55–62 s after tempo 1.1.

## 3. Record the voice
- Each paragraph separately, 1–2 s silence between, repeat a paragraph from its beginning if you stumble.
- Record the hook paragraphs twice (normal / more energy). Phone 15–20 cm from the mouth, room without echo.
- Keep the RAW file. If you also run a vendor enhancer, keep both; they must stay sample-aligned (same length).

## 4. Transcribe and choose takes
1. `ffmpeg -i raw.m4a -ac 1 -ar 48000 audio/raw.wav` and a 16 kHz copy: `ffmpeg -i raw.m4a -ac 1 -ar 16000 audio/raw16.wav`.
2. Download the ASR model once: `curl -L -o turbo.tar.bz2 https://github.com/k2-fsa/sherpa-onnx/releases/download/asr-models/sherpa-onnx-whisper-turbo.tar.bz2 && tar xjf turbo.tar.bz2` (≈ 540 MB).
3. `python3 tools/asr_chunks.py audio/raw16.wav sherpa-onnx-whisper-turbo fa` → list of groups with text; identify false starts and the best take of each paragraph (normally the LAST complete one).
4. Write `audio/takes.json`: one section per beat in film order, `start`/`end` in raw seconds, `gap_before` (0.12 intro, 0.38–0.55 between beats, 0.65 before the tail), `room_tone` = a 2 s stretch of pure silence. The refrain take is used twice (intro and tail).
5. `python3 tools/asr_phrases.py audio/raw16.wav sherpa-onnx-whisper-turbo audio/takes.json fa` → one line per phrase. ASR spelling is approximate: you write the real text.

## 5. Edit and process the voice
1. `python3 tools/edit_vo.py audio/takes.json audio/raw.wav audio/phrases_raw.json audio/raw.wav audio/vo_edit.wav [audio/enh.wav audio/vo_enh_edit.wav]`
2. `bash tools/voice_chain.sh raw audio/vo_edit.wav audio/vo.wav` (or `enhanced` for the vendor file). Expect −16 LUFS.
3. Listen to every cut. If a word is clipped, lower `low_db` (e.g. −55) or extend that section's `end` in takes.json.

## 6. Script → timing
1. Write `audio/script.json`: `phrases` = one string per line of phrases_raw.json (same order, same count!), `lines` = caption grouping (intro/tail excluded), `keywords` = word → colour role, `tempo` = 1.1.
2. `python3 tools/make_timing.py audio/phrases_raw.json audio/script.json timing.js`
3. Edit `reel.config.js` → `roles` (which phrase index plays which beat) and `anchors` (the word inside a phrase that triggers an event).
4. `node tools/dump_events.js` → prints scene starts; fix anchors until no "anchor word not found" error.
5. `node tools/sync_durations.js` → writes durations into index.html.

## 7. Brand and copy
Fill every field of `reel.config.js` (identity, palette, blobs, examples, wall, odometer, pros, tabs, bars word, pain boxes, tool, capture, cats, badge, device rows, cloud tag, no-boxes, CTA). Logo: the placeholder ring uses your tool colours — replace with a vector logo ONLY if you have the right to use it.

## 8. Real capture
Record the product doing the gesture (8–10 s). Crop to the interesting area, 960 px wide, 30 fps, no audio:
`ffmpeg -ss 4.4 -to 12.8 -i capture.mp4 -vf "crop=1320:1100:260:330,scale=960:-2,fps=30" -an -c:v libx264 -crf 18 -pix_fmt yuv420p -movflags +faststart assets/video/real.mp4`
(no capture yet → `bash tools/make_placeholder_capture.sh`). Set `capture.sourceSeconds` to its length.

## 9. Sound design and master
1. `node tools/dump_events.js` (again, after any timing change).
2. Map pack files to roles in `audio/sfx_map.json`.
3. `python3 tools/sfx_mix.py audio/vo.wav audio/sfx_map.json audio/ev.json audio/premix.wav audio/sfx.wav`
4. `bash tools/master.sh audio/premix.wav audio/mix.wav` → −14 LUFS, peak ≤ −0.8 dBFS. Check the SFX stem is ≈ 8 LU under the voice: `ffmpeg -i audio/sfx.wav -af ebur128 -f null -`.

## 10. Check and render
1. `npx hyperframes lint` → 0 errors.
2. `bash tools/render.sh renders/reel_v1.mp4` (snapshots 11 key moments first → `renders/snapshots/contact-sheet*.jpg`; fix anything wrong before the full render).
3. Spot-check the MP4: `ffmpeg -ss <t> -i renders/reel_v1.mp4 -frames:v 1 check.png` at whips, reveal and CTA; loudness `ffmpeg -i renders/reel_v1.mp4 -af ebur128 -f null -`.
4. Alternative voice on the same picture: `ffmpeg -i renders/reel_v1.mp4 -i audio/mix_enh.wav -map 0:v -map 1:a -c:v copy -c:a aac -b:a 256k -shortest -movflags +faststart renders/reel_v1_alt.mp4`.

## 11. Publish
Caption template (house format): hook line + emoji / 2–3 lines what it is / 3–5 `✦` bullets / "save this 📌" line / `کامنت کن «{{CTA_KEYWORD}}» تا لینکش رو برات دایرکت بفرستم 👇` + second route / 5–7 hashtags. Music in the platform editor at 15–25 %, lift on the reveal.
