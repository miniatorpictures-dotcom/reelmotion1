# Decisions and pitfalls (from the real build)

Format: **Problem → Cause → Fix (and why)**.

## Planning / content
1. **A reference said "180+ formats", the official site said 244 (17 categories).** → References go stale. → Fact-check every number on the product's official page on the day you script; speak a rounded, durable form («بیشتر از دویست») and show the exact number on screen (odometer lands on 244).
2. **"N other formats" sounded like N extra.** → Persian «دیگه» after a number. → «همین‌جوری بیشتر از N تا … رو عوض کن».
3. **"Offline" was overstated** (optional engines download on first use). → «روی سیستم خودت انجام می‌شه» + caveat in the caption. **"No Office needed"** was first dropped, then restored once the official site confirmed it.
4. **Platform support** (Windows stable, macOS/Linux preview) → put it in the caption, not in the VO.
5. **Hook choice.** Show-first beats explain-first for a gesture-based tool: three escalating examples with a refrain (image → document → video), tool name hidden until the reveal, the modifier key shown only in example 1. In revision the refrain also became the cold open (first 1.4 s) and the tail (bookend).
6. **No face available** → glass cards and UI mock-ups replaced the presenter-based effects; the real screen capture supplies proof.
7. **One hero effect per scene** kept the combination of 4 design languages from feeling busy.

## Persian typography
8. **Per-letter effects break Persian letter joining.** → Animate whole words; per-letter only for Latin (wordmark). Typing effects use growing prefixes of the word (each prefix is shaped correctly).
9. **Arabic comma after a Latin word landed on the wrong side.** → The whole word "PDF،" was inside an LTR-isolated span. → Split trailing punctuation out of the span: `<span class="lat">PDF</span>،`.
10. **Long word overflowed on the monitor at 360 px.** → Fixed font size. → Per-word scale `[0.78, 1.0, 1.3, 1.45]`.

## Composition (HyperFrames / GSAP / CSS)
11. **lint: `missing_timeline_registry`** although the timeline was registered in `main.js`. → The linter reads index.html statically. → `main.js` exports `window.__buildMain`; an inline `<script>` in index.html does `window.__timelines["main"] = window.__buildMain();`.
12. **Detection-tag text invisible.** → `.tag{color:#0d0d0f;background:currentColor}` — currentColor became the dark text colour. → Set the tag background inline to the box colour.
13. **Red boxes, steel bars and fuse hidden behind browser tabs.** → Tabs had z-index 10–14; the world layer got a transform (screen shake) and became a stacking context, so the tabs out-ranked later siblings. → Give the tabs wrapper `z-index:0` (its own stacking context).
14. **Floating badge hidden behind the real-capture video.** → The `<video>` is a sibling above `#world`. → Put overlays that must cover it into `#over`.
15. **Captions overlapped during handover.** → In/out windows overlapped. → In at `s − 0.05` (0.18 s), out at `next.s − 0.16` (0.10 s).
16. **CRT-off revealed the previous scene.** → Monitor collapses to a line; nothing below it. → Black backdrop layer under the monitor.
17. **Whip frames were blank.** → CSS `filter: blur(16px)` on the 3240 px strip in software GL. → No blur; fast slide (0.36 s `power4.inOut`) + 9 light streaks; examples 2–3 pre-visible on their panels.
18. **Undefined CSS variable after templating** (avatar gradient used `--purple`). → Grep `var(--…)` against the defined tokens after every palette change.
19. **Elements initialised with CSS transforms conflict with GSAP** → initial states are set with `tl.set(…, 0)` or `fromTo(…, {immediateRender:false})`, never with CSS `transform`.

## Audio
20. **ASR model download refused** (model hub not allowed on the network). → Use GitHub release assets of sherpa-onnx (`asr-models/sherpa-onnx-whisper-turbo.tar.bz2`, int8 encoder/decoder).
21. **Whisper dropped the last words of each chunk.** → No trailing silence. → Pad 0.3 s before and 1.0 s after each chunk; group pieces < 0.9 s apart; keep groups < 28 s (the model window is 30 s).
22. **Cuts clipped soft word endings ("حجم").** → Cut points at the −36/−38 dB silence edge. → Refine each boundary on a 5 ms envelope down to −52 dBFS (+30 ms tail, −20 ms head).
23. **Gaps between cuts were digital silence (−120 dB)** → audible "gate" between phrases. → Fill every gap with the recording's own room tone.
24. **Vendor-enhanced voice sounded synthetic.** → Over-processing. → Offer the raw file with a light chain; if the enhanced file must be used, add 10 % small-room convolution + −64 dB room tone and soften highs (shelf −2.5 dB @ 9 kHz). Deliver both versions on the same picture (cut points are shared because the files are sample-aligned — verify lag = 0 by cross-correlation).
25. **SFX were inaudible** (stem −35.6 LUFS vs voice −15.5). → Raw synthesized hits at low gains. → Real pack, every sample normalised (loudest 100 ms = −12 dB RMS), per-cue gains, 4.5 dB ducking, SFX stem ≈ −24 LUFS, master −14 LUFS / −1 dBTP.
26. **Some pack WAVs could not be read** by libsndfile. → Unusual encodings. → Decode every sample through ffmpeg (f32le, 48 kHz, stereo).
27. **Atempo** 1.1 brought 66.4 s to 60.3 s without audible artefacts; do not go above 1.12.

## Environment
28. **HyperFrames could not find Chrome** → `export PRODUCER_HEADLESS_SHELL_PATH=<headless_shell>` or `npx hyperframes browser ensure`.
29. **Killing helper processes by pattern killed the shell itself** (`pkill -f pattern` matched its own command). → Wait for a log line instead of pkill.
30. **Render time**: screenshot capture + software GL ≈ 7 min per 60 s at 2 workers — snapshot key frames first (`npx hyperframes snapshot --at …`) and render only after the contact sheet looks right.
