# Prompt library

Prompts that produced good results in the original build, cleaned of identity data. `{{…}}` = fill in. Persian prompts are kept in Persian (that is how the creator works); each has **Use** and **When**.

---
## P1 — Analyse a reference reel
```
این ریل رو ببین و بهم بگو راجع به چیه؟
```
Follow-up for the second/third reference:
```
اینم ببین و برداشتت رو بگو.
```
**Use:** the assistant extracts frames (ffmpeg tile grid, ~16 frames per reel, 4×2 tiles at 360 px wide), reads on-screen text, names the format, the structure, the hook, the CTA and the visual language, and says what is reusable.
**When:** start of every project; collect 2–4 references with different strengths (structure, visual language, motion technique).

## P2 — Extract the full text of a reference
```
می‌خوام این ریل آخری رو فارسی‌سازی‌شده بسازم. اول متن همون ویدیو رو بهم بده.
```
**Use:** captions are extracted at 2 fps from the caption band (crop y 67–81 % of the frame, tile 2×12), giving narration word by word + on-screen text per chapter.
**When:** when you localise an existing reel; the text tells you its argument order.

## P3 — Read a JS-rendered page (e.g. a public prompt library)
```
این لینک رو می‌تونی ببینی و موقع ساخت ریل ازش استفاده کنی: {{PUBLIC_URL}}
```
**Use:** if a plain fetch returns only "enable JavaScript", the assistant opens the page in a real browser and reads the DOM text / code blocks.
**When:** effect or prompt libraries hosted on Notion-like builders.

## P4 — Localise the scenario with a better hook (two ideas)
```
اون ریلی که انتخاب کردیم رو می‌خوام بسازیم. سناریوش رو فارسی‌سازی کن. لازم نیست حتماً بر اساس ساختار همون پست باشه؛ می‌تونیم تغییرش بدیم و بهترش کنیم، مخصوصاً توی هوک. دو تا ایده سناریو بده.
```
**Use:** two complete scene-by-scene scripts (VO + what is on screen) in the creator's storytelling structure (contrast hook → proof → uses → insight → CTA → comic tail), plus a fact-check of every claim against the product's official page.
**When:** before writing your own idea — it gives you a baseline to beat.

## P5 — Turn your own idea into a scenario
```
ایده‌ی خودم برای سناریو اینه:
سه تا مثال پشت سر هم نشون می‌ده. {{EXAMPLE_1_LINE}} بکشش بنداز این تو، حالا {{RESULT_1}}.
یا {{EXAMPLE_2_LINE}}! بکشش بنداز این تو. و یه مثال سوم همین شکلی.
بعد می‌گیم {{PAIN_LINE}}. ولی این ابزار… (ابزار معرفی می‌شه).
نظرت چیه؟ روی این کار کن.
```
**Use:** the assistant keeps your wording, adds escalation between examples, hides the tool name until the reveal, shows the key gesture only once, and closes the pain/solution loop (each pain item is answered later).
**When:** whenever you have a hook in mind — your own wording beats a generic one.

## P6 — Add a payoff line, with honest wording
```
بعد از مثال سوم بگیم که {{N}} فرمت دیگه رو هم آفلاین و رایگان بدون هیچ محدودیتی عوض کن!
```
**Use:** the assistant flags wording that viewers can attack ("N other formats" sounds like N *extra*; "offline" may be overstated) and proposes: «و همین‌جوری بیشتر از {{N}} تا … رو عوض کن؛ رایگان، روی سیستم خودت، بدون هیچ محدودیتی!»
**When:** any claim with a number, "free", "offline", "unlimited".

## P7 — Combine design references into motion ideas
```
این لینک‌ها رو هم چک کن به‌همراه رفرنس‌های ویدیویی که تو همین چت دادم. از ترکیب این‌ها به شکلی خلاقانه که نه شلوغ و زیاده‌کاری بشه نه خیلی ساده، برسیم به یک خروجی حرفه‌ای.
لینک‌ها: {{FRAMEWORK_DOCS_URL}} {{MOTION_RULES_SKILL_URL}} {{REFERENCE_REPO_URL}}
این ویدیو هم درسته روی ریتم موزیکه ولی سبک جلوه‌هاش رو خیلی دوست دارم، ازش الگو بگیر.
جدا از سناریوی فعلی، سه تا ایده بگو که با این ترکیب دیزاینی برای موشن‌مون چه ایده‌هایی می‌تونیم داشته باشیم که جذاب‌تر بشه.
```
**Use:** three distinct design languages (e.g. "words do what they say", "machine-vision HUD", "glass cards over the presenter"), each mapped to concrete scenes, plus global rules (one hero effect per scene, palette discipline, micro-SFX) and a Persian-typography warning.
**When:** after the scenario is fixed and before production.

## P8 — Merge everything into one production scenario + asset list
```
همه‌ی این ایده‌ها رو ترکیب کن در کل طول ریل و از هر کدوم در جای مناسب استفاده کن، به نسبتش سناریوی ویدیو هم بده. اگر جایی برای موضعی نیاز به فوتیج، ویدیو یا المان اضافه هست که تهیه کنم و بهت بدم، بگو چی می‌خوای.
```
**Use:** scene table (time, VO, visual, hero effect) + required assets (voice, fonts, avatar) and optional ones (real screen capture, product logo).
**When:** last planning step.

## P9 — Final VO script for recording
```
متن نهایی برای ویدیو رو بفرست تا ضبط کنم و بهت بدم، بعد تو شروع کنی.
```
**Use:** numbered paragraphs, «/» = short pause, «…» = longer pause, **bold** = stress, pronunciation notes for Latin words, recording tips (one paragraph per take with 1–2 s silence, record the hook twice, phone 15–20 cm, no echo).
**When:** before recording. Ask pronunciation questions here (e.g. HEIC → «هیک»).

## P10 — Production kick-off
```
اینم وکال. {{OPTIONAL: کمی با ابزار تمیز کردم ولی هنوز یه کم رباتیکه؛ روش کار کن ولی طبیعی و تمیز باشه.}} تپق هم داره و هر جا تپق زدم از اول اون متن رو گفتم. حالا کار رو شروع کن و می‌خوام واقعاً حرفه‌ای، تمیز و با دیتیل جذاب طراحی کنی.
```
**Use:** full pipeline (references/step-by-step.md §4–§9).

## P11 — Revision round
```
حالا می‌خوام اون تیکه‌ی آخرش که می‌گه «{{REFRAIN}}» رو بذاری اول اول به‌عنوان هوک و آخرش هم باشه.
وکال خام رو می‌دم، خودت دوباره روش ادیت بزن ببینم بهتر می‌شه یا نه.
بعضی جاها که کات زدی، کلمه یه کم ناقص افتاده؛ روشون کار کن.
از این پک ساند افکت هم استفاده کن و نسبت صداها رو جوری تنظیم کن که مسترینگش خوب باشه و همه‌ی صداها شنیده بشه.
```
**Use:** refrain as cold open + tail, re-edit from the raw file with envelope-refined cuts and room-tone gaps, real SFX pack, −14 LUFS master, two versions (raw voice / enhanced voice) on the same picture.

## P12 — Caption and music
```
یه کپشن هم بده براش.
```
```
موزیک برای بک‌گراندش چی پیشنهاد می‌دی؟
```
**Use:** caption in the house format (hook line + emoji → 2–3 lines → 3–5 ✦ bullets → save line → keyword CTA → 5–7 hashtags) with honest platform notes; music = minimal tech/glitch or lo-fi electronic, 100–120 BPM, no vocals, lift placed on the reveal, music volume 15–25 % in the editor.

---
## Effect-prompt pattern (for building a new effect with an AI coding tool)
Structure that worked for one-prompt effects (described in our own words, not copied):
1. A short **MY SETTINGS** block at the top (3 values in brackets, e.g. title / end value / colour) and a rule: "if I typed values after the prompt they win; if the brackets are still the examples, ask me once".
2. A plain-language **what it looks like** paragraph (every motion with its easing).
3. A **settings file** with every tunable number commented.
4. **Tools and folder rules**: one project folder reused across effects, ask before installing, never touch the original footage.
5. **Build steps** ending in "render ONE check frame, look at it, then render the video".
6. **How it should look** checklist used to verify the render.
