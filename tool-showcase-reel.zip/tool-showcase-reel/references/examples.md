# Worked example (fictional brand)

## Input
**Brief:** `kitchenatlas.studio` — a Persian home-cooking channel (audience: home cooks 20–40, tone: warm, playful, practical). It presents **Measuro** (مژرو), a fictional free, open-source app that converts recipe units: long-press a recipe, drag it, and a ring of units opens under the finger. Facts (from the product page, fictional): 120 units in 9 categories, Android/iOS/Web, works without internet, no ads, no account.

**Palette (same logic and count as the template):** bg #100c0a, bg2 #221a16, ink #f6efe4, accent #ffc34d (saffron), focus #e5533d (tomato), ex1 #ff9f43, ex2 #6ab0ff, ex3 #e86aa8, extra #a58cf0 #7c63c9 #6fbf73 #ff7a45, tool #d9774b #b85a33 #4c9a5b + icon #ffe2cf.

**Script (assets/example/script.json, 37 phrases):**
```
0  بکشش بنداز این تو.                                        ← cold open (monitor)
1  یه دستور پخت با «کاپ» داری؟  2 بکشش بنداز این تو…  3 حالا گرم.
4  یا می‌خوای دمای فر رو  5 از فارنهایت به سانتی‌گراد ببری؟  6 اونم بکشش بنداز همین تو.
7  دستور برای چهار نفره ولی ده تا مهمون داری؟  8 اونم بکشش بنداز این تو و ×۱۰ تحویلش بگیر.
9  و همین‌جوری بیشتر از صد تا واحد رو تبدیل کن؛  10 رایگان،  11 روی گوشی خودت،  12 بدون هیچ تبلیغی!
13 یکی از خسته‌کننده‌ترین کارای آشپزی، گشتن دنبال جدول تبدیل واحده.  14 هرکدومم یه جور دردسر دارن؛
15 یکی تبلیغ، 16 یکی ناقصه، 17 یکی ثبت‌نام می‌خواد…  18 و آخرش دستت آردیه و داری از این سایت به اون سایت می‌ری.
19 ولی این ابزار… اسمش مژرو‌ئه.  20 رایگان و متن‌باز.
21 آرد، 22 شکر، 23 کره، 24 شیر، 25 ادویه، 26 حتی بدون اینترنت، 27 دما و زمان پخت، وزن و حجم، 28 حتی قاشق و 29 پیمانه.
30 چون همه‌چی روی گوشی خودت انجام می‌شه؛ 31 نه تبلیغی داره، نه محدودیت 32 تعداد داره، 33 نه ثبت‌نام.
34 کامنت کن «پیمانه» 35 تا لینکش رو برات بفرستم.
36 بکشش بنداز این تو.                                        ← tail (monitor)
```
**Config:** `assets/composition/reel.config.js` (every field filled for this brand). Roles/anchors: ex1 = 1/2/3, ex2 = 4/6 (drop on «همین»), ex3 = 7/8 (drop on «×۱۰»), odometer spins on «صد», lands on «واحد», bars on «دردسر», fuse «ولی» → hit «اسمش» → logo «مژرو», badge «اینترنت», strikes «تبلیغی», «محدودیت», «ثبت», typing ««پیمانه»».

## Output (rendered from the template with the example timing)
| Time (s) | Scene | What happens |
|---|---|---|
| 0.00–1.39 | cold open | «بکشش» «بنداز» «این» «تو» hard-cut on the LCD monitor, then punch-through |
| 1.39 | S1 | brownie.recipe card (chip CUP, amber box `cups · 3 items · 0.98`), "Hold" key, ring of units, drop on GRAM at 4.23 → chip GRAM, flash, ✓ |
| 5.11 | S2 | whip + streaks → oven.note (°F, blue box) → drop at 9.37 → °C chip unfolds, dog-ear + °C stamp |
| 10.01 | S3 | whip → tahdig.recipe (×4, pink) → drop at 13.99 → ×10, ingredient bars grow |
| 15.20 | S4 | zoom-out to a mini row; 46 unit chips burst; odometer lands on ۱۲۰ at 16.97 («واحد · ۹ دسته»); chips رایگان / روی گوشی خودت / بدون تبلیغ |
| 21.95 | S5 | 5 fake recipe-converter tabs with flashing ads; «دردسر» behind steel bars at 27.32; red boxes ads / missing units / signup; "time wasted" timer; tabs shuffle |
| 35.13 | S6 | fuse from «ولی» → flash at 36.31 → ring logo in tool colours, "Measuro" wordmark at 36.67, tagline DRAG · DROP · MEASURED, chips رایگان / متن‌باز · MIT / Android · iOS · Web |
| 38.99 | S7 | lockup moves up; real-capture window (placeholder); 10 ingredient/unit chips light up; Wi-Fi badge struck → «لازم نیست ✓» at 43.79 |
| 49.04 | S8 | device outline draws, three converted recipes; cloud `upload: NO MATCH`; boxes تبلیغ / محدودیت تعداد / ثبت‌نام struck one by one |
| 55.34 | S9 | «کامنت کن «پیمانه»», comment box types the keyword at 56.03, DM bubble |
| 58.42 | S10 | monitor refrain again, CRT off at 59.78, end 60.33 |

Frames of this render are in the PDF guide (chapter "Final result"). The same template rendered the original reel without any code change — only `reel.config.js`, `script.json`, `takes.json`, `sfx_map.json` and the media differ.

## Cross-domain dry run (why the template generalises)
Tested mentally on a third, unrelated domain — a language-learning app ("drag a sentence into the ring → choose a language"): examples (Persian → English, voice note → text, photo of a menu → translation), payoff ("more than 100 languages"), pain (copy-paste between translator sites), reveal, categories (languages), local (works offline on the phone), CTA. Every beat and every config field has a natural counterpart; the only adaptation is the `thumb` type per example (`image` / `doc` / `media`) and the payoff (`flash` / `stamp` / `bars`). If a product has no drag gesture, change `keyLabel` and the ring labels to the product's own choice UI (e.g. a radial "share" menu) — the ring is a generic radial chooser.
