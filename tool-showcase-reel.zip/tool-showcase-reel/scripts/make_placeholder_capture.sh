#!/usr/bin/env bash
# Creates assets/video/real.mp4 = a neutral 8.4 s placeholder (960x800, 30 fps) when you have no screen capture yet.
# Replace it with your real capture later: crop to the interesting area, scale to 960 px wide, 30 fps, no audio:
#   ffmpeg -ss <start> -to <end> -i capture.mp4 -vf "crop=W:H:X:Y,scale=960:-2,fps=30" -an -c:v libx264 -crf 18 -pix_fmt yuv420p -movflags +faststart assets/video/real.mp4
set -euo pipefail
mkdir -p assets/video
ffmpeg -v error -y -f lavfi -i "color=c=0x1d1a18:s=960x800:d=8.4:r=30" \
  -vf "drawgrid=w=80:h=80:t=1:c=0x3a3330@0.6,drawbox=x=380:y=300:w=200:h=200:color=0xffc34d@0.25:t=fill" \
  -an -c:v libx264 -crf 18 -pix_fmt yuv420p -movflags +faststart assets/video/real.mp4
echo "placeholder written: assets/video/real.mp4"
