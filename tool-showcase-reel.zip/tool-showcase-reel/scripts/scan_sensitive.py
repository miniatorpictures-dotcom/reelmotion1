"""Pre-publish scan: search every text file (and PDF text) of a deliverable for strings that must not be there.
usage: python3 scan_sensitive.py <terms.txt> <path> [<path> ...]
terms.txt: one term per line (real brand names, handles, e-mails, domains, people, project names, in every spelling).
Exit code 1 if anything is found."""
import sys, os, re, zipfile, subprocess

terms = [t.strip() for t in open(sys.argv[1], encoding="utf8") if t.strip() and not t.startswith("#")]
hits = 0
def scan_text(name, text):
    global hits
    low = text.lower()
    for t in terms:
        if t.lower() in low:
            hits += 1; i = low.index(t.lower())
            print(f"HIT  {name}: '{t}' … {text[max(0, i - 40):i + 40]!r}")
for p in sys.argv[2:]:
    paths = [os.path.join(d, f) for d, _, fs in os.walk(p) for f in fs] if os.path.isdir(p) else [p]
    for f in paths:
        if f.endswith(".zip"):
            with zipfile.ZipFile(f) as z:
                for n in z.namelist():
                    if not n.endswith("/"):
                        try: scan_text(f + ":" + n, z.read(n).decode("utf8", "ignore"))
                        except Exception: pass
        elif f.endswith(".pdf"):
            txt = subprocess.run(["pdftotext", "-layout", f, "-"], capture_output=True, text=True).stdout
            scan_text(f, txt)
        else:
            try: scan_text(f, open(f, encoding="utf8", errors="ignore").read())
            except Exception: pass
print("hits:", hits)
sys.exit(1 if hits else 0)
