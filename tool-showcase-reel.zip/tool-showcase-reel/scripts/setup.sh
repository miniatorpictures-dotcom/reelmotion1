#!/usr/bin/env bash
# One-time project setup. usage: scripts/setup.sh <project_dir>
# Creates the project from assets/composition, installs HyperFrames + GSAP + fonts, and a free Persian font (Vazirmatn)
# as the default "FA" family. To use your own Persian font, overwrite assets/fonts/fa-{300,500,700,800,900}.woff2
# (convert .ttf with: npx ttf2woff2 < in.ttf > out.woff2, or keep .ttf and change the extension in index.html).
set -euo pipefail
SKILL=$(cd "$(dirname "$0")/.." && pwd)
P=${1:?project dir}
mkdir -p "$P"/{assets/fonts,assets/video,audio,tools,renders}
cp "$SKILL"/assets/composition/{index.html,main.js,events.js,reel.config.js} "$P"/
cp "$SKILL"/assets/tools/* "$P"/tools/
cp "$SKILL"/scripts/{dump_events.js,sync_durations.js,render.sh,make_placeholder_capture.sh} "$P"/tools/
cd "$P"
[ -f package.json ] || npm init -y >/dev/null
npm i hyperframes gsap @fontsource/sora @fontsource/jetbrains-mono @fontsource/vazirmatn >/dev/null
cp node_modules/gsap/dist/gsap.min.js assets/
cp node_modules/@fontsource/sora/files/sora-latin-{400,600,700,800}-normal.woff2 assets/fonts/
cp node_modules/@fontsource/jetbrains-mono/files/jetbrains-mono-latin-{400,500,700}-normal.woff2 assets/fonts/
for w in 300 500 700 800 900; do cp node_modules/@fontsource/vazirmatn/files/vazirmatn-arabic-$w-normal.woff2 assets/fonts/fa-$w.woff2; done
pip install --break-system-packages -q numpy scipy soundfile sherpa-onnx 2>/dev/null || pip install -q numpy scipy soundfile sherpa-onnx
echo "Setup done in $P. Next: put your capture in assets/video/real.mp4 (or run tools/make_placeholder_capture.sh)."
