// Writes the timing-dependent numbers into index.html (the renderer reads them statically):
// root data-duration, audio data-duration, real-capture video data-start / data-duration / data-playback-rate.
// usage (from the project dir, after dump_events.js): node tools/sync_durations.js
globalThis.window = globalThis;
const fs = require("fs"), path = require("path");
require(path.resolve("reel.config.js"));
const EV = JSON.parse(fs.readFileSync("audio/ev.json", "utf8"));
const cap = CFG.capture;
const vStart = Math.round(EV.video * 1000) / 1000;
const vDur = Math.round(Math.min(cap.sourceSeconds / cap.playbackRate, EV.S8 + 0.35 - EV.video) * 1000) / 1000;
let h = fs.readFileSync("index.html", "utf8");
h = h.replace(/(data-composition-id="main"[^>]*data-duration=")[0-9.]+/, `$1${EV.DUR}`)
     .replace(/(<audio id="mix"[^>]*data-duration=")[0-9.]+/, `$1${EV.DUR}`)
     .replace(/(<video id="realvid"[^>]*data-start=")[0-9.]+(" data-duration=")[0-9.]+(" data-playback-rate=")[0-9.]+/, `$1${vStart}$2${vDur}$3${cap.playbackRate}`);
fs.writeFileSync("index.html", h);
console.log("index.html synced: duration", EV.DUR, "video", vStart, vDur);
