#!/usr/bin/env bash
# Lint, snapshot key frames, render. usage (from the project dir): tools/render.sh [out.mp4]
# If HyperFrames can't find Chrome, point it at a headless shell:
#   export PRODUCER_HEADLESS_SHELL_PATH=/path/to/chrome-headless-shell   (or run: npx hyperframes browser ensure)
set -euo pipefail
OUT=${1:-renders/reel.mp4}
npx hyperframes lint
T=$(node -e 'const e=require(require("path").resolve("audio/ev.json"));console.log([e.monIntro[0]+.1,e.e1Drop+.3,e.S3+.3,e.odoLand+.3,e.bars+.4,e.box3+.3,e.fuseHit+.6,e.cats[4],e.strike[2]+.3,e.dm+.3,e.mon[1]].map(x=>x.toFixed(2)).join(","))')
npx hyperframes snapshot --at "$T" --no-end -o renders/snapshots
echo "Check renders/snapshots/contact-sheet*.jpg before the full render."
npx hyperframes render -o "$OUT" -f 30 -q delivery --video-frame-format png -w auto
