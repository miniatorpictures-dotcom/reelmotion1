// Computes the event map (events.js) in node and writes audio/ev.json for the SFX builder.
// usage (from the project dir): node tools/dump_events.js
globalThis.window = globalThis;
require(require("path").resolve("reel.config.js"));
require(require("path").resolve("timing.js"));
require(require("path").resolve("events.js"));
require("fs").writeFileSync("audio/ev.json", JSON.stringify(EV, null, 1));
console.log("DUR", EV.DUR, "| scenes", ["S1", "S2", "S3", "S4", "S5", "S6", "S7", "S8", "S9", "S10"].map((k) => k + "=" + EV[k].toFixed(2)).join(" "));
