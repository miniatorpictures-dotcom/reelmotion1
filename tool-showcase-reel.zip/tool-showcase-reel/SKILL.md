---
name: tool-showcase-reel
author: نیما امینی
description: Builds a ~60 s vertical (1080×1920) Persian/RTL motion-graphics reel that showcases a software tool or app — refrain cold open on an LCD "pixel monitor", three drag-and-drop examples with a glass radial chooser, odometer payoff, "pain" scene with fake browser tabs, fuse reveal of the tool, real-capture window, CTA comment box — from a recorded voice-over, with take selection, envelope-safe cuts, SFX and −14 LUFS master. Use for requests like "ریلز معرفی ابزار بساز", "ریل موشن برای این اپ", "فارسی‌سازی این ریل معرفی ابزار", "tool showcase reel", "product promo reel with voice-over", "HyperFrames reel from my voice".
---

# Tool-showcase reel (Persian, vertical, motion-only)

## 1. Overview
Produces one MP4 (1080×1920, 30 fps, H.264 + AAC, −14 LUFS, ≤ −1 dBTP), ~55–62 s, built with HyperFrames (HTML + one paused GSAP timeline) from:
- the creator's own recorded voice (raw and/or vendor-enhanced),
- a script with a fixed 11-beat structure (references/step-by-step.md §2),
- `reel.config.js` (all copy, colours, product data),
- optional real screen capture of the product and an SFX pack.

Quality bar: every caption word lights up on time; no clipped word; no blank or broken frames; one hero effect per scene; Persian text never split per letter; every claim fact-checked on the product's official page; SFX audible but always under the voice (≈ 8 LU below).

## 2. Intake (ask once, in one message; use the defaults if the user says "you decide")
| Variable | Question | Default |
|---|---|---|
| `{{CREATOR_HANDLE}}` | Your page handle shown top-left? | — (required) |
| `{{AVATAR_INITIAL}}` | Letter (or image) for the comment avatar? | first letter of the handle |
| `{{TOOL_NAME}}` / `{{TOOL_NAME_FA}}` | Product name (Latin and how you say it)? | — (required) |
| `{{TOOL_URL}}` | Official product page (for fact-check)? | — (required) |
| `{{TOOL_TAGLINE}}` | Product tagline (Latin caps)? | from the official page |
| `{{CTA_KEYWORD}}` | Comment keyword? | a one-word Persian noun tied to the product |
| `{{REFRAIN}}` | The repeated line? | «بکشش بنداز این تو» |
| `{{KEY_LABEL}}` | Key/gesture shown in example 1? | "Ctrl" (desktop) / "Hold" (mobile) |
| `{{EXAMPLE_1..3}}` | Three examples input → output, simple → impressive? | propose from the product's top features |
| `{{COUNT}}` | The big number (formats/units/languages…)? | official number, spoken rounded down |
| `{{LIMIT_1..3}}` | Three limits of the old way? | ads / size or count limit / sign-up |
| Palette | Brand colours? | template logic (references/technical-spec.md §3) with the user's accent |
| `{{FONT_FA}}` | Persian font files (5 weights 300/500/700/800/900)? | Vazirmatn (free) |
| Voice | Raw file? enhanced file? | raw preferred |
| Capture | Real screen capture of the product (8–10 s)? | placeholder clip |
| SFX pack | Path to a UI/whoosh SFX pack? | none → synthesized hits only (warn: weaker) |

## 3. Workflow
1. **References & facts** — analyse each reference reel with frame grids; fact-check the product (references/step-by-step.md §1). Use prompts P1–P3 (references/prompt-library.md).
2. **Scenario** — fill `assets/templates/script-template.md` with the user's wording (P4–P6); keep the 11 beats; tool name hidden until beat 6; three pain limits answered in beat 8 in the same order. Show it to the user; get the final VO script (P9) with pause marks and pronunciation notes.
3. **Setup** — `bash scripts/setup.sh <project>` (copies `assets/composition/*`, `assets/tools/*`, installs HyperFrames, GSAP, fonts).
4. **Voice** — transcribe (`tools/asr_chunks.py`), choose takes → `audio/takes.json` (template: `assets/example/takes.json`), phrase pass (`tools/asr_phrases.py`), edit (`tools/edit_vo.py`), process (`tools/voice_chain.sh raw|enhanced`). Details: references/step-by-step.md §4–5.
5. **Timing** — write `audio/script.json` (one entry per phrase, same count as phrases_raw.json; template `assets/example/script.json`), run `tools/make_timing.py`, set `roles` and `anchors` in `reel.config.js`, run `tools/dump_events.js` and `tools/sync_durations.js`.
6. **Brand** — fill `reel.config.js` completely (example: `assets/composition/reel.config.js`; tokens reference: `assets/tokens.json`).
7. **Capture** — crop/scale the real capture to `assets/video/real.mp4` (step-by-step §8) or `tools/make_placeholder_capture.sh`.
8. **Sound** — `audio/sfx_map.json` (template `assets/example/sfx_map.json`), `tools/sfx_mix.py`, `tools/master.sh`. Targets in references/technical-spec.md §8.
9. **Check** — `npx hyperframes lint` (0 errors) → `tools/render.sh` snapshots → read the contact sheets against the Quality checklist → full render.
10. **Deliver** — MP4 (+ alternative-voice MP4 by muxing, step-by-step §10.4), caption (P12 format), music advice. Revisions: change config/script/takes, re-run from the step that changed.

## 4. Rules
Always:
- Fact-check numbers and claims on the official product page the same day; phrase durable spoken versions («بیشتر از …»).
- Keep the user's own wording in VO, hook and titles; fix only typos.
- Animate Persian by whole words; wrap Latin words in `.lat`; keep trailing Persian punctuation outside the Latin span.
- Place every tween at absolute film time on ONE paused timeline; initial states via `tl.set(…, 0)` or `fromTo(…, {immediateRender:false})`; register the timeline in an inline script in index.html.
- Use one hero effect per scene; ACCENT for success, FOCUS for problems, max one FOCUS element per scene.
- Snapshot key frames and look at them before every full render.
- Refine voice cuts on the envelope (−52 dBFS) and fill gaps with room tone.
- Normalise every SFX sample before gains; duck SFX under speech; master to −14 LUFS / −1 dBTP.
Never:
- Never use CSS `filter: blur()` on full-width moving layers (blank frames on software GL).
- Never ship a third-party logo, screen capture with private folder names, or commercial fonts/SFX inside a public package.
- Never say the tool name before the reveal beat; never use per-letter animation on Persian.
- Never use `Math.random()` unseeded, `Date.now()`, or network fetches at render time.
- Never put overlays that must cover the capture video inside `#world` (the video sits above it) — use `#over`.

## 5. Quality checklist (before delivery)
- [ ] `npx hyperframes lint`: 0 errors, 0 warnings.
- [ ] Contact sheets: intro monitor word fully inside the frame; every whip frame shows content; ring labels legible; odometer digits correct; bars, red boxes and fuse ABOVE the tabs; badge visible over the capture; CTA avatar coloured; tail CRT-off ends on black.
- [ ] Captions: correct Persian shaping, punctuation on the correct side, no two lines visible at once.
- [ ] Audio: voice stem −16 ± 1 LUFS; SFX stem ≈ 8 LU under; master −14 ± 0.5 LUFS; true peak ≤ −1 dBTP; no clipped word at any cut (listen to every cut).
- [ ] Claims match the official page; platform caveats in the caption.
- [ ] Duration 55–62 s; refrain at start and end.

## 6. Common failures
| Symptom | Fix |
|---|---|
| lint `missing_timeline_registry` | register `window.__timelines["main"]` in an inline script in index.html |
| Detection tag text invisible | tag background inline = box colour (not `currentColor`) |
| Boxes/bars hidden behind tabs | tabs wrapper `z-index:0` |
| Badge hidden by the capture | put it in `#over` |
| Blank frames during whip | remove blur; slide + streaks |
| Two caption lines at once | in s−0.05, out next.s−0.16 |
| "anchor word not found" | anchor substring must exist in that phrase's text in script.json |
| `script has N phrases but voice has M` | split/merge script entries to match the pauses found by edit_vo.py |
| Clipped word endings | lower `low_db` in takes.json or extend that section's `end` |
| Whisper misses last word | keep the 1 s trailing pad; group < 28 s |
| SFX inaudible / too loud | check stems with ebur128; adjust per-cue gains in sfx_mix.py |
| Chrome not found | `PRODUCER_HEADLESS_SHELL_PATH` or `npx hyperframes browser ensure` |
More: references/decisions-and-pitfalls.md.
